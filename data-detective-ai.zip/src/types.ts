/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ColumnProfile {
  name: string;
  type: 'numeric' | 'categorical' | 'date';
  missingCount: number;
  missingPercentage: number;
  uniqueValues: number;
  min?: number;
  max?: number;
  mean?: number;
  stdDev?: number;
}

export interface CorrelationPair {
  colA: string;
  colB: string;
  correlation: number;
}

export interface DatasetProfile {
  name: string;
  rows: number;
  columns: number;
  memoryKb: number;
  missingValues: number;
  duplicateRows: number;
  outliersCount: number;
  healthScore: number;
  correlationScore: number;
  columnProfiles: ColumnProfile[];
  correlationMatrix: CorrelationPair[];
  sampleData: Record<string, any>[];
  problemType: 'Classification' | 'Regression' | 'Clustering' | 'Forecasting';
  suggestedTarget: string;
}

export interface Suspect {
  name: string;
  description: string;
  threatLevel: 'Low' | 'Medium' | 'CRITICAL';
}

export interface CrimeContext {
  caseNumber: string;
  crime: string;
  scene: string;
  evidence: string[];
  suspects: Suspect[];
  primeSuspect: string;
  confidence: number;
  verdict: string;
  actions: string[];
}

export interface AIInsights {
  executiveSummary: string;
  topFindings: string[];
  hiddenPatterns: string[];
  opportunities: string[];
  risks: string[];
  futurePredictions: string;
}

export interface LogEntry {
  timestamp: string;
  service: string;
  level: string;
  message: string;
}

export type ViewType = 
  | 'landing'
  | 'dashboard'
  | 'upload'
  | 'profile'
  | 'detective'
  | 'eda'
  | 'ml'
  | 'forecast'
  | 'chat'
  | 'reports'
  | 'admin'
  | 'settings';
