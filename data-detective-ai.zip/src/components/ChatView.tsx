/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { MessageSquare, Send, Sparkles, HelpCircle, CornerDownLeft, Bot, User } from "lucide-react";
import { DatasetProfile } from "../types";

interface ChatViewProps {
  profile: DatasetProfile;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function ChatView({ profile }: ChatViewProps) {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: `Hello Investigator! I am Sherlock, your AI Data Sleuth. I have ingested the dataset metadata for "${profile.name}". What clues or mysteries would you like me to crack today?` }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const sampleQuestions = [
    "Why did the main target metric decrease?",
    "Show me the top 3 anomalies or outliers.",
    "Summarize the correlation matrix highlights.",
    "Explain what actions I should take right now."
  ];

  // Auto scroll to bottom
  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;

    const updatedMessages = [...messages, { role: 'user' as const, content: text }];
    setMessages(updatedMessages);
    setInputValue("");
    setIsLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profile,
          messages: updatedMessages
        })
      });

      if (!res.ok) {
        throw new Error("Failed to communicate with Sherlock AI");
      }

      const payload = await res.json();
      setMessages(prev => [...prev, { role: 'assistant', content: payload.answer }]);

    } catch (err: any) {
      setMessages(prev => [...prev, { role: 'assistant', content: "The data trail went cold! (Gemini API limit or missing key). Please check your credentials or try again." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(inputValue);
  };

  return (
    <div id="chat-view" className="h-[calc(100vh-140px)] flex flex-col animate-fade-in text-left">
      {/* Page Title */}
      <div className="mb-4">
        <h1 className="font-display font-extrabold text-3xl text-white tracking-tight flex items-center gap-2">
          💬 Conversational Data Detective
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 font-light mt-1">
          Chat directly with Sherlock AI about the features and patterns of <span className="font-mono text-indigo-400">{profile.name}</span>.
        </p>
      </div>

      {/* Messages Window */}
      <div className="flex-1 glass-panel rounded-3xl bg-slate-950/40 border border-white/5 flex flex-col overflow-hidden">
        {/* Chat Header Status */}
        <div className="flex items-center justify-between px-6 py-3 bg-slate-950/20 border-b border-white/5">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-slate-300">Sherlock AI Agent active</span>
          </div>
          <span className="text-[9px] font-mono text-slate-500">POWERED BY GEMINI-3.5-FLASH</span>
        </div>

        {/* Scrollable messages list */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6">
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex items-start gap-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              {msg.role === 'assistant' && (
                <div className="p-2 bg-indigo-950 border border-indigo-900 rounded-xl shrink-0 text-indigo-400">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              
              <div className={`p-4 rounded-2xl max-w-lg text-xs leading-relaxed font-light ${
                msg.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-tr-none text-left shadow-lg' 
                  : 'bg-slate-900/50 border border-white/5 text-slate-200 rounded-tl-none text-left'
              }`}>
                {msg.content}
              </div>

              {msg.role === 'user' && (
                <div className="p-2 bg-slate-900 border border-white/10 rounded-xl shrink-0 text-slate-400">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex items-start gap-4 justify-start">
              <div className="p-2 bg-indigo-950 border border-indigo-900 rounded-xl shrink-0 text-indigo-400">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-4 rounded-2xl bg-slate-900/50 border border-white/5 rounded-tl-none text-slate-200 flex gap-2 items-center">
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}

          <div ref={scrollRef} />
        </div>

        {/* Prompt suggestions layout */}
        {messages.length === 1 && (
          <div className="p-6 border-t border-white/5 bg-slate-950/20 text-left space-y-3">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Suggested leads to follow:</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {sampleQuestions.map((q, i) => (
                <button
                  key={i}
                  onClick={() => sendMessage(q)}
                  className="p-3 bg-slate-900/30 hover:bg-slate-900 border border-white/5 hover:border-indigo-500/40 rounded-xl text-left text-xs text-slate-300 transition cursor-pointer"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Textbox Form */}
        <div className="p-4 border-t border-white/5 bg-slate-950/40">
          <form onSubmit={handleSubmit} className="flex gap-3 items-center relative">
            <input
              type="text"
              placeholder="Ask Sherlock a question about your spreadsheet columns..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="flex-1 bg-slate-950/80 text-xs text-slate-200 border border-white/10 rounded-2xl px-5 py-4 focus:outline-none focus:border-indigo-500 font-light pr-12"
            />
            <button
              id="btn-chat-send"
              type="submit"
              disabled={isLoading || !inputValue.trim()}
              className="p-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white rounded-xl shadow shadow-indigo-600/20 transition cursor-pointer absolute right-3"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
