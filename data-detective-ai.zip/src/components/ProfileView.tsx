/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  FileSpreadsheet, Database, AlertCircle, Trash2, 
  Layers, Star, ShieldCheck, HeartPulse, Search
} from "lucide-react";
import { DatasetProfile } from "../types";

interface ProfileViewProps {
  profile: DatasetProfile;
}

export default function ProfileView({ profile }: ProfileViewProps) {
  const [columnSearch, setColumnSearch] = useState("");
  const [activeTab, setActiveTab] = useState<'columns' | 'correlations' | 'sample'>('columns');

  // Filter columns based on search
  const filteredColumns = profile.columnProfiles.filter(col => 
    col.name.toLowerCase().includes(columnSearch.toLowerCase())
  );

  // Filter correlations
  const filteredCorrelations = profile.correlationMatrix
    .filter(pair => pair.colA !== pair.colB) // omit self correlations
    .filter((pair, idx, self) => 
      // deduplicate symmetric pairs (A-B and B-A)
      self.findIndex(p => (p.colA === pair.colB && p.colB === pair.colA)) > idx ||
      self.findIndex(p => (p.colA === pair.colA && p.colB === pair.colB)) === idx
    )
    .sort((a, b) => Math.abs(b.correlation) - Math.abs(a.correlation)); // sort by strength

  return (
    <div id="profile-view" className="space-y-8 animate-fade-in text-left">
      {/* Profile Header */}
      <div>
        <h1 className="font-display font-extrabold text-3xl text-white tracking-tight">Dataset Profile</h1>
        <p className="text-xs sm:text-sm text-slate-400 font-light mt-1">
          A microscopic mathematical audit of <span className="font-mono text-indigo-400">{profile.name}</span>. Secure evidence identified.
        </p>
      </div>

      {/* Profile Bento Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Dimensions */}
        <div className="p-5 rounded-2xl bg-slate-950/40 border border-white/5 flex flex-col justify-between">
          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500">Dimensions</span>
          <div className="mt-2">
            <div className="text-2xl font-bold font-display text-white">{profile.rows.toLocaleString()}</div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">rows × {profile.columns} columns</div>
          </div>
        </div>

        {/* Footprint */}
        <div className="p-5 rounded-2xl bg-slate-950/40 border border-white/5 flex flex-col justify-between">
          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500">RAM Memory Cache</span>
          <div className="mt-2">
            <div className="text-2xl font-bold font-display text-white">{profile.memoryKb} KB</div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">Isolated runtime cache</div>
          </div>
        </div>

        {/* Quality Anomalies */}
        <div className="p-5 rounded-2xl bg-slate-950/40 border border-white/5 flex flex-col justify-between">
          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500">Quality Flaws</span>
          <div className="mt-2">
            <div className="text-2xl font-bold font-display text-indigo-400">
              {(profile.missingValues + profile.duplicateRows).toLocaleString()}
            </div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">{profile.missingValues} blank cells | {profile.duplicateRows} dups</div>
          </div>
        </div>

        {/* Outliers */}
        <div className="p-5 rounded-2xl bg-slate-950/40 border border-white/5 flex flex-col justify-between">
          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500">Outlier Checkpoints</span>
          <div className="mt-2">
            <div className="text-2xl font-bold font-display text-cyan-400">{profile.outliersCount}</div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">IQR standard scale flags</div>
          </div>
        </div>
      </div>

      {/* Health Meter & Quality Score */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 md:col-span-2 flex flex-col sm:flex-row items-center gap-6">
          <div className="relative shrink-0 flex items-center justify-center">
            {/* SVG Health Ring */}
            <svg className="w-28 h-28 transform -rotate-90">
              <circle cx="56" cy="56" r="48" stroke="rgba(255,255,255,0.05)" strokeWidth="8" fill="transparent" />
              <circle cx="56" cy="56" r="48" stroke="url(#healthGradient)" strokeWidth="8" fill="transparent"
                strokeDasharray="301.59" strokeDashoffset={301.59 - (301.59 * profile.healthScore) / 100}
                strokeLinecap="round" />
              <defs>
                <linearGradient id="healthGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#06b6d4" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-2xl font-display font-extrabold text-white">{profile.healthScore}%</span>
              <span className="text-[8px] uppercase tracking-widest text-slate-400">Health</span>
            </div>
          </div>

          <div className="space-y-2 text-left">
            <h3 className="font-display font-bold text-lg text-white flex items-center gap-2">
              <HeartPulse className="w-5 h-5 text-indigo-400" /> Evidence Audit Score
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed font-light">
              Your dataset quality is indexed at <span className="text-white font-semibold">{profile.healthScore}/100</span>. This score measures completeness, redundancy, and structural outliers. {profile.healthScore > 85 ? "Excellent source integrity. Perfect for automated machine learning deployment." : "Minor inconsistencies detected. The AI Sherlock is resilient and has completed auto-imputation for analysis."}
            </p>
          </div>
        </div>

        {/* Suggestion box */}
        <div className="p-6 rounded-3xl bg-[#090e24] border border-indigo-950/60 flex flex-col justify-between">
          <div>
            <span className="text-[10px] uppercase font-mono tracking-widest text-indigo-400 font-semibold bg-indigo-950/60 border border-indigo-900/60 px-2.5 py-0.5 rounded">AUTO CLASSIFIER</span>
            <h4 className="font-display font-bold text-base text-white mt-3">Target Anchor Identified</h4>
            <p className="text-xs text-slate-400 mt-1 font-light leading-relaxed">
              We identified <span className="font-mono text-indigo-300 font-medium">{profile.suggestedTarget}</span> as the ideal target. Training pipeline initialized for <span className="text-white font-medium">{profile.problemType}</span> models.
            </p>
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-2">
            Target Confidence: {profile.correlationScore}%
          </div>
        </div>
      </div>

      {/* Main interactive inspect table and tabs */}
      <div className="glass-panel rounded-3xl bg-slate-950/40 overflow-hidden">
        {/* Navigation tabs */}
        <div className="flex border-b border-white/5 bg-slate-950/20 px-6">
          <button
            onClick={() => setActiveTab('columns')}
            className={`py-4 px-4 text-xs font-semibold border-b-2 transition cursor-pointer ${
              activeTab === 'columns' ? "border-indigo-500 text-white" : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            Column Metrics ({profile.columnProfiles.length})
          </button>
          <button
            onClick={() => setActiveTab('correlations')}
            className={`py-4 px-4 text-xs font-semibold border-b-2 transition cursor-pointer ${
              activeTab === 'correlations' ? "border-indigo-500 text-white" : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            Symmetric Correlations
          </button>
          <button
            onClick={() => setActiveTab('sample')}
            className={`py-4 px-4 text-xs font-semibold border-b-2 transition cursor-pointer ${
              activeTab === 'sample' ? "border-indigo-500 text-white" : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            Secured Sample Rows (100)
          </button>
        </div>

        {/* Tab contents */}
        <div className="p-6">
          {activeTab === 'columns' && (
            <div className="space-y-4">
              <div className="flex max-w-xs items-center gap-2.5 px-3 py-1.5 rounded-xl border border-white/5 bg-slate-950/40">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Filter columns..."
                  value={columnSearch}
                  onChange={(e) => setColumnSearch(e.target.value)}
                  className="bg-transparent text-xs text-white focus:outline-none w-full font-light"
                />
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="text-[10px] text-slate-500 uppercase tracking-wider border-b border-white/5 font-mono">
                    <tr>
                      <th className="pb-3 pl-3">Column Name</th>
                      <th className="pb-3">Type</th>
                      <th className="pb-3 text-right">Unique</th>
                      <th className="pb-3 text-right">Missing Count</th>
                      <th className="pb-3 text-right">Mean</th>
                      <th className="pb-3 text-right">Min</th>
                      <th className="pb-3 text-right">Max</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 font-light">
                    {filteredColumns.map((col, i) => (
                      <tr key={i} className="hover:bg-white/5 transition">
                        <td className="py-3.5 pl-3 font-semibold text-slate-100 font-mono">{col.name}</td>
                        <td className="py-3.5">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                            col.type === 'numeric' 
                              ? 'bg-blue-950/40 text-blue-400 border border-blue-900/40' 
                              : col.type === 'date' 
                                ? 'bg-cyan-950/40 text-cyan-400 border border-cyan-900/40' 
                                : 'bg-purple-950/40 text-purple-400 border border-purple-900/40'
                          }`}>
                            {col.type}
                          </span>
                        </td>
                        <td className="py-3.5 text-right font-mono">{col.uniqueValues}</td>
                        <td className="py-3.5 text-right font-mono text-slate-400">
                          {col.missingCount > 0 ? (
                            <span className="text-yellow-400 font-semibold">{col.missingCount} ({col.missingPercentage}%)</span>
                          ) : "0"}
                        </td>
                        <td className="py-3.5 text-right font-mono text-indigo-300">{col.mean !== undefined ? col.mean : "—"}</td>
                        <td className="py-3.5 text-right font-mono">{col.min !== undefined ? col.min : "—"}</td>
                        <td className="py-3.5 text-right font-mono">{col.max !== undefined ? col.max : "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'correlations' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-400 font-light">
                Pearson linear correlation analysis between numerical anchors. Closer to <span className="text-white">+1.0</span> or <span className="text-white">-1.0</span> indicates critical dependencies.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredCorrelations.slice(0, 12).map((pair, idx) => {
                  const absR = Math.abs(pair.correlation);
                  let strength = "Weaker Link";
                  let bg = "bg-slate-900/20";
                  let text = "text-slate-400";
                  
                  if (absR > 0.7) {
                    strength = "CRITICAL LEAD";
                    bg = "bg-indigo-950/30 border-indigo-900/50";
                    text = "text-indigo-400";
                  } else if (absR > 0.4) {
                    strength = "MODERATE LEAD";
                    bg = "bg-blue-950/20 border-blue-900/30";
                    text = "text-blue-400";
                  }

                  return (
                    <div key={idx} className={`p-4 rounded-xl border border-white/5 text-left flex items-center justify-between ${bg}`}>
                      <div className="overflow-hidden">
                        <div className="text-[9px] font-mono font-bold tracking-widest uppercase mb-1">
                          <span className={text}>{strength}</span>
                        </div>
                        <div className="text-xs font-semibold text-white truncate">{pair.colA}</div>
                        <div className="text-[10px] text-slate-400 mt-0.5 truncate">linked with {pair.colB}</div>
                      </div>
                      <div className={`text-xl font-display font-extrabold ${absR > 0.7 ? "text-indigo-400" : "text-slate-200"}`}>
                        {pair.correlation > 0 ? `+${pair.correlation}` : pair.correlation}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'sample' && (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="text-[10px] text-slate-500 uppercase tracking-wider border-b border-white/5 font-mono">
                  <tr>
                    <th className="pb-3 pl-3">Record index</th>
                    {Object.keys(profile.sampleData[0]).map((h, i) => (
                      <th key={i} className="pb-3">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 font-light">
                  {profile.sampleData.slice(0, 15).map((row, rIdx) => (
                    <tr key={rIdx} className="hover:bg-white/5 transition font-mono text-[11px]">
                      <td className="py-3 pl-3 text-slate-500 font-bold">#{rIdx + 1}</td>
                      {Object.keys(profile.sampleData[0]).map((h, cIdx) => {
                        const val = row[h];
                        return (
                          <td key={cIdx} className="py-3">
                            {val !== null && val !== undefined ? String(val) : <span className="text-yellow-500/85">null</span>}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="text-[10px] text-slate-500 text-center py-4 font-light">
                Displaying first 15 records in this audit preview. Complete set stored in secure execution heap.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
