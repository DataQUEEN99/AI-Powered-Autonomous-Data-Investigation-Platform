/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from "react";
import { 
  UploadCloud, FileSpreadsheet, ShieldAlert, CheckCircle2, 
  HelpCircle, ArrowRight, Play, RefreshCcw, FileText, Search
} from "lucide-react";
import { DatasetProfile } from "../types";

interface UploadViewProps {
  onDatasetLoaded: (profile: DatasetProfile, crimeContext?: any) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

export default function UploadView({ onDatasetLoaded, isLoading, setIsLoading }: UploadViewProps) {
  const [dragActive, setDragActive] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [recentUploads, setRecentUploads] = useState<{ name: string; rows: number; size: string; date: string }[]>([
    { name: "ecom_q2_revenue_decline.csv", rows: 24, size: "3.2 KB", date: "2026-06-28 02:30" },
    { name: "saas_enterprise_churn_logs.csv", rows: 24, size: "2.8 KB", date: "2026-06-27 18:15" },
    { name: "employee_burnout_scores.json", rows: 120, size: "18.4 KB", date: "2026-06-25 10:44" }
  ]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFile = async (file: File) => {
    if (!file.name.endsWith(".csv") && !file.name.endsWith(".json")) {
      setErrorMsg("Sleuth restriction: Only CSV and JSON formats can be scanned by the AI Detective.");
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const text = await file.text();
      const response = await fetch("/api/analyze-raw", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fileName: file.name, fileContent: text })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to analyze raw dataset.");
      }

      const profile = await response.json();
      setSuccessMsg(`Dataset "${file.name}" scanned successfully. Evidence secured!`);
      
      // Add to recent
      setRecentUploads(prev => [
        { name: file.name, rows: profile.rows, size: `${profile.memoryKb} KB`, date: new Date().toISOString().replace('T', ' ').substring(0, 16) },
        ...prev
      ]);

      setTimeout(() => {
        onDatasetLoaded(profile);
      }, 800);

    } catch (err: any) {
      setErrorMsg(err.message || "An error occurred during dataset examination.");
      setIsLoading(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      await processFile(e.target.files[0]);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  // Launch preloaded dataset demos
  const loadPreloadedCase = async (id: string) => {
    setIsLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const res = await fetch(`/api/datasets/${id}`);
      if (!res.ok) {
        throw new Error("Failed to load preloaded case.");
      }
      const payload = await res.json();
      setSuccessMsg(`Case dataset loaded! Entering the interactive dashboard.`);
      
      setTimeout(() => {
        onDatasetLoaded(payload.profile, payload.crimeContext);
      }, 600);

    } catch (err: any) {
      setErrorMsg(err.message || "Failed to trigger case file.");
      setIsLoading(false);
    }
  };

  return (
    <div id="upload-view" className="space-y-8 animate-fade-in">
      {/* View Header */}
      <div className="text-left">
        <h1 className="font-display font-extrabold text-3xl text-white tracking-tight">Securing the Crime Scene</h1>
        <p className="text-xs sm:text-sm text-slate-400 font-light mt-1">
          Upload your spreadsheet or launch one of our high-fidelity sample cases to start an AI data inquest.
        </p>
      </div>

      {isLoading ? (
        <div className="glass-panel p-16 rounded-3xl flex flex-col items-center justify-center space-y-6 bg-slate-950/40 min-h-[400px]">
          <div className="relative flex items-center justify-center">
            <div className="w-16 h-16 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
            <Search className="w-6 h-6 text-indigo-400 absolute animate-pulse" />
          </div>
          <div className="space-y-2 text-center">
            <h3 className="font-display font-bold text-lg text-white">Sifting Through the Evidence...</h3>
            <p className="text-xs text-slate-400 font-mono">Running statistical profiling, checking bounds, and isolating correlation anchors.</p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Upload Box */}
          <div className="lg:col-span-2 space-y-6">
            <div 
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={triggerFileInput}
              className={`border-2 border-dashed rounded-3xl p-12 text-center transition cursor-pointer flex flex-col items-center justify-center space-y-4 min-h-[350px] relative overflow-hidden ${
                dragActive 
                  ? "border-indigo-500 bg-indigo-950/20 shadow-2xl shadow-indigo-500/10" 
                  : "border-white/10 hover:border-indigo-500/60 bg-slate-950/40 hover:bg-slate-950/60"
              }`}
            >
              {/* Decorative light flare */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full filter blur-2xl pointer-events-none" />

              <div className="p-4 bg-gradient-to-tr from-indigo-500/10 to-blue-500/10 border border-indigo-500/20 rounded-2xl">
                <UploadCloud className="w-10 h-10 text-indigo-400 animate-bounce" />
              </div>

              <div className="space-y-1">
                <h3 className="font-display font-bold text-lg text-white">Drag and drop your dataset</h3>
                <p className="text-xs text-slate-400 font-light">Supported file types: <span className="font-mono text-indigo-300">.csv, .json</span></p>
                <p className="text-[10px] text-slate-500 font-light pt-2">Max file scale: 50MB (sandbox limit)</p>
              </div>

              <button 
                id="btn-upload-browse"
                type="button"
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs rounded-xl shadow-lg shadow-indigo-600/20 transition flex items-center gap-2 cursor-pointer"
              >
                Browse Spreadsheets <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <input 
                ref={fileInputRef}
                type="file" 
                accept=".csv,.json"
                onChange={handleFileChange}
                className="hidden" 
              />
            </div>

            {/* Notification messages */}
            {errorMsg && (
              <div className="p-4 bg-red-950/40 border border-red-900/40 rounded-2xl flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                <div className="text-left">
                  <span className="font-bold text-xs text-red-300">Sleuth Engine Failure</span>
                  <p className="text-xs text-red-200 mt-0.5">{errorMsg}</p>
                </div>
              </div>
            )}

            {successMsg && (
              <div className="p-4 bg-emerald-950/40 border border-emerald-900/40 rounded-2xl flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-left">
                  <span className="font-bold text-xs text-emerald-300">Evidence Secured</span>
                  <p className="text-xs text-emerald-200 mt-0.5">{successMsg}</p>
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Sample Files & Recent Uploads */}
          <div className="space-y-6">
            {/* Sample Case Dossiers */}
            <div className="glass-panel p-6 rounded-3xl bg-slate-950/40 space-y-4">
              <h3 className="font-display font-bold text-sm text-white flex items-center gap-2 border-b border-white/5 pb-3">
                <FileText className="w-4 h-4 text-indigo-400" /> Active Case Dossiers
              </h3>

              <div className="space-y-3">
                {/* Dossier 1 */}
                <div 
                  onClick={() => loadPreloadedCase("ecommerce_decline")}
                  className="p-3 bg-slate-900/50 border border-white/5 hover:border-indigo-500/40 rounded-xl text-left transition cursor-pointer flex justify-between items-center group"
                >
                  <div className="overflow-hidden">
                    <span className="text-[10px] uppercase font-mono font-bold text-red-400 bg-red-950/40 px-1.5 py-0.5 rounded border border-red-900/40">REVENUE DROPPED</span>
                    <h4 className="font-display font-bold text-xs text-white mt-1.5">E-Commerce Revenue Drop</h4>
                    <p className="text-[10px] text-slate-400 truncate mt-0.5">Solve a severe Q2 online channel conversion mystery.</p>
                  </div>
                  <Play className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 transition shrink-0 ml-2" />
                </div>

                {/* Dossier 2 */}
                <div 
                  onClick={() => loadPreloadedCase("saas_churn")}
                  className="p-3 bg-slate-900/50 border border-white/5 hover:border-indigo-500/40 rounded-xl text-left transition cursor-pointer flex justify-between items-center group"
                >
                  <div className="overflow-hidden">
                    <span className="text-[10px] uppercase font-mono font-bold text-indigo-400 bg-indigo-950/40 px-1.5 py-0.5 rounded border border-indigo-900/40 font-semibold">CUSTOMER CHURN</span>
                    <h4 className="font-display font-bold text-xs text-white mt-1.5">SaaS Enterprise Renewals</h4>
                    <p className="text-[10px] text-slate-400 truncate mt-0.5">Crack why West-timezone contract churn spiked.</p>
                  </div>
                  <Play className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 transition shrink-0 ml-2" />
                </div>
              </div>
            </div>

            {/* Recent Upload History */}
            <div className="glass-panel p-6 rounded-3xl bg-slate-950/40 space-y-4">
              <h3 className="font-display font-bold text-sm text-white flex items-center gap-2 border-b border-white/5 pb-3">
                <RefreshCcw className="w-4 h-4 text-indigo-400" /> Upload Scan History
              </h3>

              <div className="space-y-3 max-h-[220px] overflow-y-auto">
                {recentUploads.map((item, index) => (
                  <div key={index} className="flex items-center gap-3 p-2 bg-slate-900/20 border border-white/5 rounded-xl">
                    <div className="p-2 bg-slate-900 border border-white/10 rounded-lg">
                      <FileSpreadsheet className="w-4 h-4 text-slate-400" />
                    </div>
                    <div className="flex-1 text-left min-w-0">
                      <div className="text-[11px] text-slate-200 font-mono truncate">{item.name}</div>
                      <div className="flex gap-2 text-[9px] text-slate-500 mt-0.5">
                        <span>{item.rows} rows</span>
                        <span>•</span>
                        <span>{item.size}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
