/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  LayoutDashboard, UploadCloud, Search, BarChart3, 
  Brain, TrendingUp, MessageSquare, FileText, 
  ShieldAlert, Settings, LogOut, Sparkles, User, FileSpreadsheet
} from "lucide-react";
import { ViewType } from "../types";

interface SidebarProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
  activeDatasetName: string | null;
  onLogout: () => void;
}

export default function Sidebar({ currentView, onViewChange, activeDatasetName, onLogout }: SidebarProps) {
  
  const navItems = [
    { id: "dashboard" as ViewType, label: "Dashboard", icon: LayoutDashboard },
    { id: "upload" as ViewType, label: "Upload File", icon: UploadCloud },
    { id: "profile" as ViewType, label: "Dataset Profile", icon: FileSpreadsheet, disabled: !activeDatasetName },
    { id: "detective" as ViewType, label: "AI Detective Case", icon: Search, disabled: !activeDatasetName },
    { id: "eda" as ViewType, label: "Automatic EDA", icon: BarChart3, disabled: !activeDatasetName },
    { id: "ml" as ViewType, label: "Machine Learning", icon: Brain, disabled: !activeDatasetName },
    { id: "forecast" as ViewType, label: "Forecasting", icon: TrendingUp, disabled: !activeDatasetName },
    { id: "chat" as ViewType, label: "Chat with Data", icon: MessageSquare, disabled: !activeDatasetName },
    { id: "reports" as ViewType, label: "Report Generator", icon: FileText, disabled: !activeDatasetName },
    { id: "admin" as ViewType, label: "Admin Panel", icon: ShieldAlert },
    { id: "settings" as ViewType, label: "Settings", icon: Settings },
  ];

  return (
    <aside id="main-sidebar" className="w-64 border-r border-white/5 bg-slate-950/80 backdrop-blur-xl flex flex-col h-full shrink-0 select-none relative z-10">
      {/* Brand Header */}
      <div className="p-6 border-b border-white/5 flex items-center gap-3">
        <div className="p-1.5 bg-gradient-to-tr from-indigo-500 to-blue-600 rounded-lg shadow-md">
          <Search className="w-4 h-4 text-white" />
        </div>
        <div className="flex flex-col">
          <span className="font-display font-extrabold text-sm tracking-tight text-white">Data Detective AI</span>
          <span className="text-[10px] font-medium text-slate-500 tracking-wider uppercase font-mono mt-0.5">Sleuth Engine v1.0</span>
        </div>
      </div>

      {/* Selected Dataset Alert Bar */}
      {activeDatasetName ? (
        <div className="mx-4 mt-4 p-3 bg-indigo-950/20 border border-indigo-900/40 rounded-xl flex items-center gap-2.5">
          <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse shrink-0" />
          <div className="overflow-hidden">
            <div className="text-[10px] text-indigo-300 font-semibold tracking-wider uppercase">Active Inquest</div>
            <div className="text-[11px] text-slate-300 truncate font-mono mt-0.5" title={activeDatasetName}>
              {activeDatasetName}
            </div>
          </div>
        </div>
      ) : (
        <div className="mx-4 mt-4 p-3 bg-slate-900/40 border border-white/5 rounded-xl flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-yellow-500/80 animate-pulse shrink-0" />
          <div className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">
            Waiting for Dataset
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = currentView === item.id;
          const Icon = item.icon;

          return (
            <button
              id={`nav-link-${item.id}`}
              key={item.id}
              disabled={item.disabled}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-left text-xs font-medium transition duration-200 cursor-pointer ${
                isActive 
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15" 
                  : item.disabled
                    ? "text-slate-600 cursor-not-allowed opacity-45"
                    : "text-slate-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? "text-white" : "text-slate-400"}`} />
              <span className="flex-1">{item.label}</span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-white shadow" />
              )}
            </button>
          );
        })}
      </nav>

      {/* User Information */}
      <div className="p-4 border-t border-white/5 bg-slate-950/60 flex flex-col gap-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-500 flex items-center justify-center font-display font-bold text-xs text-white shadow shadow-cyan-500/25">
            AM
          </div>
          <div className="overflow-hidden">
            <div className="text-[11px] text-slate-200 font-semibold truncate font-display">Aman Nirmal</div>
            <div className="text-[10px] text-slate-500 truncate font-mono mt-0.5">amannirmal1212@gmail.com</div>
          </div>
        </div>

        <button
          id="btn-sidebar-logout"
          onClick={onLogout}
          className="w-full py-2 bg-white/5 hover:bg-red-950/30 hover:text-red-400 text-slate-400 border border-white/5 hover:border-red-900/30 rounded-xl transition text-[11px] font-semibold flex items-center justify-center gap-2 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" /> Close Case File
        </button>
      </div>
    </aside>
  );
}
