/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from "react";
import { 
  ResponsiveContainer, AreaChart, LineChart, 
  Area, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend
} from "recharts";
import { TrendingUp, Settings2, Sparkles, HelpCircle, AlertCircle, Compass } from "lucide-react";
import { DatasetProfile } from "../types";

interface ForecastViewProps {
  profile: DatasetProfile;
}

export default function ForecastView({ profile }: ForecastViewProps) {
  const [targetCol, setTargetCol] = useState(profile.suggestedTarget);
  const [periods, setPeriods] = useState<number>(12);
  const [forecastData, setForecastData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Identify date column
  const dateCol = useMemo(() => {
    const found = profile.columnProfiles.find(p => p.type === 'date');
    return found ? found.name : Object.keys(profile.sampleData[0])[0];
  }, [profile]);

  // Numeric options
  const numericColumns = useMemo(() => {
    return profile.columnProfiles.filter(c => c.type === 'numeric').map(c => c.name);
  }, [profile]);

  useEffect(() => {
    fetchForecast();
  }, [targetCol, periods, profile]);

  const fetchForecast = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/forecast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          data: profile.sampleData,
          dateCol,
          targetCol,
          periods
        })
      });

      if (!res.ok) {
        throw new Error("Failed to fetch forecast calculations");
      }

      const data = await res.json();
      setForecastData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div id="forecast-view" className="space-y-8 animate-fade-in text-left">
      {/* Page Title */}
      <div>
        <h1 className="font-display font-extrabold text-3xl text-white tracking-tight">Predictive Trend Forecasting</h1>
        <p className="text-xs sm:text-sm text-slate-400 font-light mt-1">
          Generate auto-regressive seasonality projections of key metric vectors.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Controllers */}
        <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-6 lg:col-span-1 h-fit">
          <h3 className="font-display font-bold text-sm text-white flex items-center gap-2 border-b border-white/5 pb-3">
            <Settings2 className="w-4 h-4 text-indigo-400" /> Forecast Settings
          </h3>

          {/* Metric Selector */}
          <div className="space-y-2">
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Target Vector</label>
            <select
              value={targetCol}
              onChange={(e) => setTargetCol(e.target.value)}
              className="w-full bg-slate-900 border border-white/5 text-xs text-white rounded-xl p-3 focus:outline-none focus:border-indigo-500 font-light cursor-pointer"
            >
              {numericColumns.map((c, i) => (
                <option key={i} value={c}>{c}</option>
              ))}
            </select>
          </div>

          {/* Date Axis (Inferred) */}
          <div className="space-y-2">
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Date index (Inferred)</label>
            <div className="p-3 bg-slate-900/60 border border-white/5 rounded-xl font-mono text-xs text-slate-300">
              {dateCol}
            </div>
          </div>

          {/* Periods selection */}
          <div className="space-y-2">
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Forecast Horizon</label>
            <div className="grid grid-cols-3 gap-2">
              {[12, 24, 36].map((p) => (
                <button
                  key={p}
                  onClick={() => setPeriods(p)}
                  className={`py-2 px-1 rounded-xl font-medium text-xs transition cursor-pointer text-center ${
                    periods === p ? "bg-indigo-600 text-white" : "bg-slate-900/50 text-slate-400 border border-white/5 hover:text-white"
                  }`}
                >
                  {p} periods
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Forecast Canvas Chart */}
        <div className="lg:col-span-3 p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4">
          <div className="flex justify-between items-center border-b border-white/5 pb-4">
            <div className="text-left">
              <h3 className="font-display font-bold text-sm text-white">Seasonality Projection Map</h3>
              <p className="text-[10px] font-mono text-slate-500 mt-0.5">Fitting: Linear Seasonality Fourier factors</p>
            </div>
            <span className="text-[10px] uppercase font-mono text-cyan-400 font-semibold bg-cyan-950/40 border border-cyan-900/60 px-2 py-0.5 rounded">
              Confidence Interval: 85%
            </span>
          </div>

          {isLoading ? (
            <div className="h-[380px] w-full flex flex-col items-center justify-center space-y-4">
              <div className="w-10 h-10 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
              <span className="text-xs text-slate-500 font-mono">Fitting exponential parameters...</span>
            </div>
          ) : (
            <div className="space-y-4 animate-fade-in">
              <div className="h-[340px] w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={forecastData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                    <defs>
                      <linearGradient id="forecastConf" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.15} />
                        <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.01} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                    <XAxis dataKey="date" stroke="#64748b" fontSize={10} tickLine={false} />
                    <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: "#020617", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px", fontSize: "11px" }} />
                    <Legend verticalAlign="top" height={36} iconType="circle" />
                    
                    {/* Confidence Bound Band */}
                    <Area type="monotone" dataKey="upperBound" stroke="transparent" fill="url(#forecastConf)" name="Upper Confidence Range" />
                    <Area type="monotone" dataKey="lowerBound" stroke="transparent" fill="transparent" name="Lower Confidence Range" />

                    {/* Historical Actuals */}
                    <Line type="monotone" dataKey="actual" stroke="#3b82f6" strokeWidth={2.5} dot={{ r: 3 }} name="Historical Data" connectNulls />
                    
                    {/* Forecasted Line */}
                    <Line type="monotone" dataKey="predicted" stroke="#06b6d4" strokeWidth={2.5} strokeDasharray="5 5" dot={{ r: 3 }} name="AI Forecast" connectNulls />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Informative footer */}
              <div className="p-4 bg-slate-900/40 border border-white/5 rounded-2xl flex items-start gap-3 text-left">
                <AlertCircle className="w-5 h-5 text-indigo-400 mt-0.5 shrink-0" />
                <p className="text-xs text-slate-400 font-light leading-relaxed">
                  <span className="font-semibold text-slate-300">Statistical Analysis:</span> The model evaluated historical seasonal variations to compute a mean standard deviation band. Projections suggest a stable trend line with high confidence across the {periods} periods horizon.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
