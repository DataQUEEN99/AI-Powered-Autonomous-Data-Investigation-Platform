/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Settings, User, KeyRound, Mail, Sparkles, CheckCircle2 } from "lucide-react";

export default function SettingsView() {
  const [name, setName] = useState("Aman Nirmal");
  const [email, setEmail] = useState("amannirmal1212@gmail.com");
  const [role, setRole] = useState("Lead Analytical Investigator");
  const [notifEnabled, setNotifEnabled] = useState(true);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg("Investigator profiles synced successfully with sandbox instance.");
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  return (
    <div id="settings-view" className="space-y-8 animate-fade-in text-left">
      {/* Page Title */}
      <div>
        <h1 className="font-display font-extrabold text-3xl text-white tracking-tight">Sleuth Settings</h1>
        <p className="text-xs sm:text-sm text-slate-400 font-light mt-1">
          Configure credentials, secrets key alignments, and workspace parameters.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Columns: Profile settings form */}
        <div className="lg:col-span-2 space-y-6">
          <form onSubmit={handleSave} className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4">
            <h3 className="font-display font-bold text-sm text-white flex items-center gap-2 border-b border-white/5 pb-3">
              <User className="w-4 h-4 text-indigo-400" /> Investigator Credentials
            </h3>

            {/* Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Full Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-900 border border-white/5 text-xs text-white rounded-xl p-3 focus:outline-none focus:border-indigo-500 font-light"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-900 border border-white/5 text-xs text-white rounded-xl p-3 focus:outline-none focus:border-indigo-500 font-light"
                />
              </div>

              <div className="space-y-2 sm:col-span-2">
                <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Agency Role</label>
                <input
                  type="text"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full bg-slate-900 border border-white/5 text-xs text-white rounded-xl p-3 focus:outline-none focus:border-indigo-500 font-light"
                />
              </div>
            </div>

            {/* Notification Check */}
            <div className="flex items-center gap-3 pt-2">
              <input
                type="checkbox"
                checked={notifEnabled}
                onChange={(e) => setNotifEnabled(e.target.checked)}
                className="w-4 h-4 rounded border-white/10 bg-slate-900 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
              />
              <span className="text-xs text-slate-400 font-light">Receive automated crime alerts when outliers spike.</span>
            </div>

            {/* Buttons */}
            <div className="flex justify-between items-center pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs rounded-xl shadow-lg shadow-indigo-600/20 transition cursor-pointer font-semibold"
              >
                Save Investigator Profile
              </button>
            </div>

            {successMsg && (
              <div className="p-3 bg-emerald-950/30 border border-emerald-900/30 text-emerald-300 text-xs rounded-xl flex items-center gap-2 font-light">
                <CheckCircle2 className="w-4 h-4 shrink-0" /> {successMsg}
              </div>
            )}
          </form>
        </div>

        {/* Right Column: API Secrets & Security Guides */}
        <div className="space-y-6">
          {/* API Secrets Instructions */}
          <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4">
            <h3 className="font-display font-bold text-sm text-white flex items-center gap-2 border-b border-white/5 pb-3">
              <KeyRound className="w-4 h-4 text-indigo-400" /> Platform Security
            </h3>

            <div className="space-y-3 font-light text-xs text-slate-400 leading-relaxed">
              <p>
                Data Detective AI runs fully server-side. Your Google Gemini API credentials are automatically and securely managed by the workspace control panel.
              </p>
              <div className="p-3.5 bg-indigo-950/20 border border-indigo-900/40 rounded-xl space-y-1.5 text-left text-[11px]">
                <div className="font-semibold text-slate-200">How to manage Keys:</div>
                <ul className="list-disc pl-4 space-y-1 text-slate-300 font-mono text-[10px]">
                  <li>Navigate to Settings &gt; Secrets panel.</li>
                  <li>Set `GEMINI_API_KEY` secret.</li>
                  <li>Our Node backend handles the rest.</li>
                </ul>
              </div>
              <p className="text-[10px] text-slate-500">
                Your keys are never visible in browser inspect elements or bundled in client Javascript files.
              </p>
            </div>
          </div>

          {/* Email verification block */}
          <div className="p-6 rounded-3xl bg-[#090e24] border border-indigo-950/60 space-y-3">
            <h3 className="font-display font-bold text-sm text-white flex items-center gap-2">
              <Mail className="w-4 h-4 text-indigo-400" /> Agency Verification
            </h3>
            <p className="text-xs text-slate-400 font-light leading-relaxed">
              Ensure your email address is fully verified with the analytical registry for continuous API usage.
            </p>
            <button
              onClick={() => { alert("Verification link dispatched to amannirmal1212@gmail.com!"); }}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white border border-white/10 text-[11px] font-semibold rounded-xl transition cursor-pointer"
            >
              Dispatch Verification link
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
