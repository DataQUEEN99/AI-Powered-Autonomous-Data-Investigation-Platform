/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { FileText, Download, CheckCircle2, FileVideo, Table, FilePenLine } from "lucide-react";
import { DatasetProfile, AIInsights } from "../types";

interface ReportGeneratorViewProps {
  profile: DatasetProfile;
}

export default function ReportGeneratorView({ profile }: ReportGeneratorViewProps) {
  const [insights, setInsights] = useState<AIInsights | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState<string | null>(null);

  useEffect(() => {
    fetchInsights();
  }, [profile]);

  const fetchInsights = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ profile })
      });

      if (!res.ok) {
        throw new Error("Insights retrieval failed");
      }

      const data = await res.json();
      setInsights(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const simulateExport = (type: string) => {
    setIsExporting(type);
    setTimeout(() => {
      setIsExporting(null);
      // Trigger simple local blob download representing the exported file
      const dummyContent = `DATA DETECTIVE AI REPORT EXPORT\n==============================\nDataset: ${profile.name}\nProfile rows: ${profile.rows}\nProfile columns: ${profile.columns}\nReport Date: 2026-06-28\n\nExecutive Summary:\n${insights?.executiveSummary || "Analyzed dataset."}`;
      const blob = new Blob([dummyContent], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${profile.name.replace(/\.[^/.]+$/, "")}_Sherlock_Report.${type === 'pdf' ? 'pdf' : type === 'ppt' ? 'pptx' : 'xlsx'}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }, 1200);
  };

  return (
    <div id="report-generator-view" className="space-y-8 animate-fade-in text-left">
      {/* Page Title */}
      <div>
        <h1 className="font-display font-extrabold text-3xl text-white tracking-tight">Executive Report Generator</h1>
        <p className="text-xs sm:text-sm text-slate-400 font-light mt-1">
          Compile deep findings, business implications, and presentation notes into exportable formats.
        </p>
      </div>

      {isLoading ? (
        <div className="glass-panel p-16 rounded-3xl flex flex-col items-center justify-center space-y-6 bg-slate-950/40 min-h-[400px]">
          <div className="w-12 h-12 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
          <div className="space-y-1 text-center">
            <h3 className="font-display font-bold text-base text-white">Synthesizing Business Brief...</h3>
            <p className="text-[10px] text-slate-500 font-mono">Formulating opportunities, calculating risks, and arranging notes.</p>
          </div>
        </div>
      ) : insights ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Compiled report body */}
          <div className="lg:col-span-2 space-y-6">
            {/* Executive Summary */}
            <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-3">
              <h3 className="font-display font-bold text-base text-white border-b border-white/5 pb-3">
                1. Executive Analytical Summary
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed font-light whitespace-pre-line pt-2">
                {insights.executiveSummary}
              </p>
            </div>

            {/* Findings & Patterns */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Findings */}
              <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-3">
                <h3 className="font-display font-bold text-sm text-white border-b border-white/5 pb-2">
                  Top Forensic Discoveries
                </h3>
                <ul className="space-y-2.5 pt-2">
                  {insights.topFindings.map((f, i) => (
                    <li key={i} className="flex gap-2 text-xs text-slate-300 font-light">
                      <span className="text-indigo-400 font-bold font-mono">#{i + 1}</span>
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Patterns */}
              <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-3">
                <h3 className="font-display font-bold text-sm text-white border-b border-white/5 pb-2">
                  Hidden Data Relationships
                </h3>
                <ul className="space-y-2.5 pt-2">
                  {insights.hiddenPatterns.map((p, i) => (
                    <li key={i} className="flex gap-2 text-xs text-slate-300 font-light">
                      <span className="text-cyan-400 font-bold font-mono">#{i + 1}</span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Opportunities & Risks */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Opportunities */}
              <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-3">
                <h3 className="font-display font-bold text-sm text-white border-b border-white/5 pb-2">
                  Remediation Opportunities
                </h3>
                <ul className="space-y-2.5 pt-2">
                  {insights.opportunities.map((o, i) => (
                    <li key={i} className="flex gap-2 text-xs text-slate-300 font-light">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{o}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Risks */}
              <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-3">
                <h3 className="font-display font-bold text-sm text-white border-b border-white/5 pb-2">
                  Critical Process Risks
                </h3>
                <ul className="space-y-2.5 pt-2">
                  {insights.risks.map((r, i) => (
                    <li key={i} className="flex gap-2 text-xs text-slate-300 font-light">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0" />
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Export & Presentation sidebar */}
          <div className="space-y-6">
            {/* Export options */}
            <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4">
              <h3 className="font-display font-bold text-sm text-white border-b border-white/5 pb-3">
                Download Briefings
              </h3>

              <div className="space-y-2">
                <button
                  onClick={() => simulateExport("pdf")}
                  disabled={!!isExporting}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white font-medium text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4" /> {isExporting === 'pdf' ? 'Rendering PDF...' : 'Download PDF Executive Summary'}
                </button>
                <button
                  onClick={() => simulateExport("ppt")}
                  disabled={!!isExporting}
                  className="w-full py-3 bg-white/5 hover:bg-white/10 text-white border border-white/10 font-medium text-xs rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <FileVideo className="w-4 h-4 text-orange-400" /> {isExporting === 'ppt' ? 'Packing PPTX...' : 'Download PPT Presentation Deck'}
                </button>
                <button
                  onClick={() => simulateExport("xlsx")}
                  disabled={!!isExporting}
                  className="w-full py-3 bg-white/5 hover:bg-white/10 text-white border border-white/10 font-medium text-xs rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Table className="w-4 h-4 text-emerald-400" /> {isExporting === 'xlsx' ? 'Exporting Sheet...' : 'Export Audited Clean Sheet'}
                </button>
              </div>
            </div>

            {/* Presentation Notes */}
            <div className="p-6 rounded-3xl bg-[#090e24] border border-indigo-950/60 space-y-3">
              <h3 className="font-display font-bold text-sm text-white flex items-center gap-2">
                <FilePenLine className="w-4 h-4 text-indigo-400" /> Speaker Notes
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed font-light">
                {insights.futurePredictions}
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-slate-400 font-light py-12 text-center text-xs font-mono">
          Failed to compile insights. Check database keys.
        </div>
      )}
    </div>
  );
}
