/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { ShieldAlert, Server, Activity, Database, Users, HardHat, RefreshCw } from "lucide-react";
import { LogEntry } from "../types";

export default function AdminPanelView() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchLogs();
    const interval = setInterval(fetchLogs, 8000);
    return () => clearInterval(interval);
  }, []);

  const fetchLogs = async () => {
    try {
      const res = await fetch("/api/logs");
      if (res.ok) {
        const data = await res.json();
        setLogs(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const adminStats = [
    { title: "Isolated DB Instances", value: "Cloud Run Container Sandbox", icon: Server, desc: "Active Node process on Port 3000" },
    { title: "Concurrent Sleuths", value: "3 Active Sessions", icon: Users, desc: "Aman Nirmal + 2 Sandbox Guests" },
    { title: "Gemini API Invocations", value: "244 Calls", icon: Activity, desc: "Quota limits: 15 RPM" },
    { title: "Storage Allocated", value: "482 MB Cache", icon: Database, desc: "Dynamic RAM Cache heap space" }
  ];

  return (
    <div id="admin-panel-view" className="space-y-8 animate-fade-in text-left">
      {/* Page Title */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="font-display font-extrabold text-3xl text-white tracking-tight flex items-center gap-2">
            🛡️ Administrative Control Panel
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-light mt-1">
            Real-time analytics, server status indicators, and background system event streaming.
          </p>
        </div>
        <button
          onClick={fetchLogs}
          className="p-2 border border-white/5 bg-slate-900/60 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Admin Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {adminStats.map((stat, idx) => (
          <div key={idx} className="p-5 rounded-2xl bg-slate-950/40 border border-white/5 flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500">{stat.title}</span>
              <stat.icon className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="mt-4">
              <div className="text-sm font-bold font-display text-white">{stat.value}</div>
              <div className="text-[9px] text-slate-500 font-mono mt-0.5">{stat.desc}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Audit Logs Console */}
      <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4">
        <div className="flex justify-between items-center border-b border-white/5 pb-4">
          <div>
            <h3 className="font-display font-bold text-sm text-white">Live Event Log Stream</h3>
            <p className="text-[10px] text-slate-500 mt-0.5 font-mono">Process: node dist/server.cjs</p>
          </div>
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
        </div>

        {/* Logs Terminal window */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-white/5 font-mono text-[10px] leading-relaxed overflow-x-auto h-[260px] space-y-2">
          {logs.map((log, idx) => {
            let levelColor = "text-blue-400";
            if (log.level === "SUCCESS") levelColor = "text-emerald-400";
            if (log.level === "WARN" || log.level === "ERROR") levelColor = "text-red-400 font-bold";

            return (
              <div key={idx} className="flex gap-4 hover:bg-white/5 py-0.5 rounded px-2 transition">
                <span className="text-slate-500 shrink-0">{log.timestamp.substring(11, 19)}</span>
                <span className={`font-bold shrink-0 ${levelColor}`}>[{log.service}]</span>
                <span className="text-slate-300">{log.message}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
