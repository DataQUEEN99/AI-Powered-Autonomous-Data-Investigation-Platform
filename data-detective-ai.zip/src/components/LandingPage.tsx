/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion } from "motion/react";
import { 
  Search, ShieldCheck, Database, BrainCircuit, Terminal, Sparkles, 
  HelpCircle, ArrowRight, CheckCircle2, ChevronDown, Award, Play, Github 
} from "lucide-react";

interface LandingPageProps {
  onStart: () => void;
  onTryDemo: () => void;
}

export default function LandingPage({ onStart, onTryDemo }: LandingPageProps) {
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setActiveFaq(activeFaq === index ? null : index);
  };

  const features = [
    {
      icon: Search,
      title: "Sherlock Detective Engine",
      description: "Our unique narrative AI investigates your dataset as a crime scene. It isolates evidence, names prime suspects (factors), and delivers an immersive final verdict.",
      color: "from-blue-500 to-indigo-500"
    },
    {
      icon: Database,
      title: "Full-Spectrum Profiling",
      description: "Instant data ingestion with dynamic checks for memory use, missing cells, outlier bounds, duplicate records, and multi-variable Pearson correlations.",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: BrainCircuit,
      title: "Explainable ML (SHAP)",
      description: "Auto-detects target variables to train tree-based ensembles (XGBoost, LightGBM, Random Forests). Inspects feature importance, Confusion Matrices, and ROC curves.",
      color: "from-cyan-500 to-teal-500"
    },
    {
      icon: Terminal,
      title: "Forecasting & Chat",
      description: "Chat with your data using natural language, asking complex business questions. Generate auto-regressive seasonality projections with a single click.",
      color: "from-yellow-500 to-amber-500"
    }
  ];

  const pricingPlans = [
    {
      name: "Apprentice Sleuth",
      price: "$0",
      description: "For individual analysts cracking basic mysteries.",
      features: [
        "Up to 5 CSV/JSON uploads / month",
        "Standard Automated EDA charts",
        "Standard Correlation matrix",
        "Local browser persistence only"
      ],
      cta: "Start Free Investigation",
      popular: false,
      onAction: onStart
    },
    {
      name: "Chief Investigator",
      price: "$49",
      period: "/month",
      description: "Unleash full AI powers to crack advanced business anomalies.",
      features: [
        "Unlimited CSV, JSON, and Google Sheets",
        "Deep AI Detective Investigations (Gemini-3.5-flash)",
        "XGBoost AutoML & SHAP feature importances",
        "Printable PDF & PowerPoint Report Generator",
        "Extended AI Chat with Data"
      ],
      cta: "Unlock Chief Status",
      popular: true,
      onAction: onStart
    },
    {
      name: "Corporate Syndicate",
      price: "Custom",
      description: "Secure, scaled database intelligence for high-profile agencies.",
      features: [
        "Google Cloud SQL & PostgreSQL live hooks",
        "Google Workspace & Drive automated syncing",
        "Enterprise-grade SLA & isolated storage instances",
        "Custom domain reports & team collaboration rails",
        "24/7 Dedicated Senior Analytical support"
      ],
      cta: "Deploy Syndicate",
      popular: false,
      onAction: onStart
    }
  ];

  const faqs = [
    {
      q: "How does the AI 'investigate' a dataset?",
      a: "Instead of simply plotting points, our system processes your dataset mathematically to find anomalies, critical correlation changes, and extreme value outliers. We then pass these structured statistics to Gemini to write an immersive, narrative crime investigation—correlating variables like 'out of stock events' as suspect factors that lead to the 'crime' (e.g. revenue drop)."
    },
    {
      q: "Are my uploaded datasets secure?",
      a: "Absolutely. All processing occurs in private memory arrays on our isolated Cloud Run instance. We do not persist your records to disk unless explicitly linked to an authenticated Cloud SQL database. Your data is never used to train global LLM parameters."
    },
    {
      q: "What file formats do you support?",
      a: "We natively support structured CSV and JSON files in this trial. Our full Enterprise tier connects directly with SQL Databases, Google Sheets, and cloud files (Google Drive, Dropbox, OneDrive) for continuous analysis."
    },
    {
      q: "Is there a size limit for files?",
      a: "The standard trial allows files up to 50MB in size, which easily fits several millions of records for typical business CSV or JSON dumps."
    }
  ];

  return (
    <div id="landing-page" className="min-h-screen bg-[#050816] text-slate-100 overflow-hidden relative">
      {/* Dynamic Background Glowing Blobs */}
      <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] bg-indigo-900/20 rounded-full filter blur-[150px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] bg-blue-900/10 rounded-full filter blur-[150px] pointer-events-none" />

      {/* Premium Header */}
      <header className="border-b border-white/5 py-4 px-6 md:px-12 flex justify-between items-center bg-slate-950/40 backdrop-blur-md relative z-10">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-xl shadow-lg shadow-indigo-500/20">
            <Search className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="font-display font-bold tracking-tight text-xl text-white">Data Detective AI</span>
            <span className="hidden sm:inline-block ml-2 text-[10px] uppercase tracking-widest text-indigo-400 bg-indigo-950/60 border border-indigo-900/60 px-2 py-0.5 rounded">Trial Sandbox</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button 
            id="btn-login"
            onClick={onStart}
            className="text-sm font-medium text-slate-300 hover:text-white transition cursor-pointer"
          >
            Log In
          </button>
          <button 
            id="btn-start-nav"
            onClick={onStart}
            className="text-sm font-medium bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white px-5 py-2 rounded-xl transition shadow-lg shadow-indigo-600/20 flex items-center gap-2 cursor-pointer"
          >
            Start Inquest <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative px-6 md:px-12 pt-16 pb-24 max-w-7xl mx-auto flex flex-col items-center text-center">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl"
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 border border-indigo-500/30 bg-indigo-950/40 rounded-full mb-8 text-xs text-indigo-300 backdrop-blur-sm">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Meet Sherlock for your spreadsheets</span>
          </div>

          <h1 className="font-display font-extrabold text-4xl sm:text-5xl md:text-7xl text-white tracking-tight leading-none mb-6">
            Every Dataset Has a <span className="bg-gradient-to-r from-blue-400 via-indigo-400 to-cyan-400 bg-clip-text text-transparent">Story</span>.<br />
            Every Mystery Has an <span className="bg-gradient-to-r from-cyan-400 via-emerald-400 to-teal-400 bg-clip-text text-transparent">Answer</span>.
          </h1>

          <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed font-light">
            Upload any CSV or spreadsheet. Our narrative AI detective instantly investigates anomalies, uncovers deep patterns, auto-trains ML models, and chats with your data.
          </p>

          <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
            <button 
              id="btn-hero-investigate"
              onClick={onStart}
              className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-medium rounded-2xl transition shadow-xl shadow-indigo-600/35 flex items-center justify-center gap-3 cursor-pointer"
            >
              <Search className="w-5 h-5" /> Start Investigation
            </button>
            <button 
              id="btn-hero-demo"
              onClick={onTryDemo}
              className="w-full sm:w-auto px-8 py-4 bg-white/5 hover:bg-white/10 text-white border border-white/10 font-medium rounded-2xl transition flex items-center justify-center gap-3 cursor-pointer"
            >
              <Play className="w-5 h-5 text-indigo-400 fill-indigo-400" /> Try Sample Case
            </button>
          </div>
        </motion.div>

        {/* Hero Interactive Element (Magnifying Glass over glowing data preview) */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 1 }}
          className="w-full max-w-5xl mt-16 rounded-3xl overflow-hidden glass-panel border border-white/10 p-2 bg-slate-950/60 shadow-2xl relative"
        >
          {/* Dashboard Window Header Decor */}
          <div className="flex items-center justify-between px-4 py-2 bg-slate-900/50 border-b border-white/5 rounded-t-2xl">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-red-500/80" />
              <span className="w-3 h-3 rounded-full bg-yellow-500/80" />
              <span className="w-3 h-3 rounded-full bg-green-500/80" />
            </div>
            <div className="text-xs font-mono text-slate-500">CASE-DD-2026-ACTIVE.csv</div>
            <div className="w-3" />
          </div>

          <div className="p-4 md:p-8 flex flex-col md:flex-row gap-6 items-center">
            {/* Visual Case File Mockup */}
            <div className="w-full md:w-1/2 text-left space-y-4">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 text-[9px] bg-red-950/60 text-red-400 border border-red-900/60 rounded font-mono font-bold uppercase tracking-wider">CRITICAL ANOMALY</span>
                <span className="text-xs font-mono text-indigo-400">#CASE-2026</span>
              </div>
              <h3 className="font-display font-bold text-2xl text-white">The Mystery of the Vanishing Conversions</h3>
              <p className="text-xs text-slate-400 leading-relaxed font-light">
                Why did conversions drop 43% in Region North while advertising budgets were rising? Our AI Detective analyzed 24 inventory checkpoints to crack the riddle.
              </p>

              {/* Solved clue blocks */}
              <div className="space-y-2 pt-2">
                <div className="p-3 bg-indigo-950/30 border border-indigo-900/40 rounded-xl flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-indigo-400 mt-0.5 shrink-0" />
                  <div className="text-xs">
                    <span className="font-semibold text-slate-300">Evidence Found:</span> Stockout frequency peaked during marketing push in region.
                  </div>
                </div>
                <div className="p-3 bg-cyan-950/30 border border-cyan-900/40 rounded-xl flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
                  <div className="text-xs">
                    <span className="font-semibold text-slate-300">Prime Suspect Named:</span> Inventory Replenishment Delay (r = -0.84 to NPS).
                  </div>
                </div>
              </div>
            </div>

            {/* Glowing Case Stats Panel */}
            <div className="w-full md:w-1/2 p-6 rounded-2xl bg-[#090e24] border border-white/5 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full filter blur-xl" />
              <div className="flex justify-between items-center border-b border-white/5 pb-4 mb-4">
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-indigo-400" />
                  <span className="text-sm font-semibold text-white">Inquest Metrics</span>
                </div>
                <span className="text-xs text-emerald-400 font-mono font-bold bg-emerald-950/60 border border-emerald-900/60 px-2 py-0.5 rounded">SOLVED</span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-slate-900/40 border border-white/5 rounded-xl text-left">
                  <div className="text-[10px] text-slate-400 uppercase tracking-wider">Health Score</div>
                  <div className="text-2xl font-bold font-display text-white mt-0.5">92%</div>
                </div>
                <div className="p-3 bg-slate-900/40 border border-white/5 rounded-xl text-left">
                  <div className="text-[10px] text-slate-400 uppercase tracking-wider">Target Correlation</div>
                  <div className="text-2xl font-bold font-display text-white mt-0.5">-0.84</div>
                </div>
                <div className="p-3 bg-slate-900/40 border border-white/5 rounded-xl text-left">
                  <div className="text-[10px] text-slate-400 uppercase tracking-wider">Anomalies Isolated</div>
                  <div className="text-2xl font-bold font-display text-indigo-400 mt-0.5">14</div>
                </div>
                <div className="p-3 bg-slate-900/40 border border-white/5 rounded-xl text-left">
                  <div className="text-[10px] text-slate-400 uppercase tracking-wider">Sleuth Confidence</div>
                  <div className="text-2xl font-bold font-display text-cyan-400 mt-0.5">96%</div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Feature Showcase Section */}
      <section className="relative py-24 px-6 md:px-12 bg-slate-950/30 border-y border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="font-display font-bold text-3xl sm:text-5xl text-white tracking-tight mb-4">
              Equipped to Solve Any Data Mystery
            </h2>
            <p className="text-slate-400 font-light">
              Built on powerful statistical algorithms and high-reasoning LLMs, we transform plain records into rich, narrative crime solving exercises.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feat, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -8 }}
                className="glass-panel glass-panel-hover p-6 rounded-3xl text-left flex flex-col justify-between"
              >
                <div>
                  <div className={`p-3 bg-gradient-to-br ${feat.color} rounded-2xl w-fit mb-6 shadow-md`}>
                    <feat.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-display font-bold text-xl text-white mb-2">{feat.title}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed font-light">{feat.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 px-6 md:px-12 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="font-display font-bold text-3xl sm:text-5xl text-white tracking-tight mb-4">
            Investigation Agency Licenses
          </h2>
          <p className="text-slate-400 font-light">
            Choose the depth of your investigative agency. Sign up risk-free in seconds.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricingPlans.map((plan, i) => (
            <div 
              key={i}
              className={`rounded-3xl p-8 text-left flex flex-col justify-between h-full relative ${
                plan.popular 
                  ? "bg-slate-900/60 border-2 border-indigo-500/80 shadow-2xl shadow-indigo-500/10" 
                  : "glass-panel bg-slate-950/40 border-white/5"
              }`}
            >
              {plan.popular && (
                <span className="absolute top-0 right-6 -translate-y-1/2 bg-gradient-to-r from-blue-500 to-indigo-600 text-[10px] font-bold text-white px-3 py-1 rounded-full uppercase tracking-wider">
                  Highly Requested
                </span>
              )}
              <div>
                <h3 className="font-display font-bold text-xl text-white mb-2">{plan.name}</h3>
                <p className="text-xs text-slate-400 mb-6 font-light">{plan.description}</p>
                
                <div className="flex items-baseline gap-1 mb-6 border-b border-white/5 pb-6">
                  <span className="text-4xl font-extrabold text-white">{plan.price}</span>
                  {plan.period && <span className="text-xs text-slate-400 font-light">{plan.period}</span>}
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feat, j) => (
                    <li key={j} className="flex items-start gap-2 text-xs text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button 
                onClick={plan.onAction}
                className={`w-full py-3 px-4 rounded-xl font-medium text-xs transition cursor-pointer text-center ${
                  plan.popular 
                    ? "bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-lg" 
                    : "bg-white/5 hover:bg-white/10 text-white border border-white/10"
                }`}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 px-6 md:px-12 bg-slate-950/20 border-t border-white/5">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-display font-bold text-3xl text-white tracking-tight flex items-center justify-center gap-3">
              <HelpCircle className="w-8 h-8 text-indigo-400 animate-pulse" /> Frequently Solved Inquiries
            </h2>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <div 
                key={idx}
                className="glass-panel rounded-2xl overflow-hidden transition-all duration-300"
              >
                <button 
                  onClick={() => toggleFaq(idx)}
                  className="w-full p-6 text-left flex justify-between items-center gap-4 text-white hover:text-indigo-300 transition cursor-pointer"
                >
                  <span className="font-semibold text-sm sm:text-base">{faq.q}</span>
                  <ChevronDown className={`w-5 h-5 text-slate-400 shrink-0 transition-transform duration-300 ${activeFaq === idx ? 'rotate-180 text-indigo-400' : ''}`} />
                </button>
                
                {activeFaq === idx && (
                  <div className="px-6 pb-6 text-xs sm:text-sm text-slate-400 leading-relaxed font-light border-t border-white/5 pt-4">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Premium Footer */}
      <footer className="border-t border-white/5 py-12 px-6 md:px-12 bg-slate-950">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8 text-center md:text-left">
          <div className="space-y-2">
            <div className="flex items-center gap-2 justify-center md:justify-start">
              <Search className="w-5 h-5 text-indigo-400" />
              <span className="font-display font-bold text-lg text-white">Data Detective AI</span>
            </div>
            <p className="text-xs text-slate-500 font-light">Every Dataset Has a Story. Every Mystery Has an Answer.</p>
          </div>
          <div className="flex flex-wrap justify-center gap-6 text-xs text-slate-400 font-light">
            <a href="#" onClick={(e) => { e.preventDefault(); onStart(); }} className="hover:text-indigo-400 transition">Sandbox Workspace</a>
            <a href="#" onClick={(e) => { e.preventDefault(); onStart(); }} className="hover:text-indigo-400 transition">Terms of Agency</a>
            <a href="#" onClick={(e) => { e.preventDefault(); onStart(); }} className="hover:text-indigo-400 transition">Sleuth Privacy Protocol</a>
            <a href="#" onClick={(e) => { e.preventDefault(); onStart(); }} className="hover:text-indigo-400 transition">API Documentation</a>
          </div>
          <div className="text-[10px] text-slate-600 font-mono">
            © 2026 Data Detective AI. Powered by Google Gemini-3.5-flash.
          </div>
        </div>
      </footer>
    </div>
  );
}
