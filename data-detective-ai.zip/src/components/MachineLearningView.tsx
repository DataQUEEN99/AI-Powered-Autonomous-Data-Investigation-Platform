/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { 
  ResponsiveContainer, BarChart, LineChart, 
  Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend
} from "recharts";
import { Brain, Award, ShieldAlert, Sparkles, AlertCircle, TrendingUp, Settings } from "lucide-react";
import { DatasetProfile } from "../types";

interface MachineLearningViewProps {
  profile: DatasetProfile;
}

export default function MachineLearningView({ profile }: MachineLearningViewProps) {
  const [selectedModel, setSelectedModel] = useState<string>("XGBoost Ensemble");
  const [isTraining, setIsTraining] = useState<boolean>(false);
  const [isTrained, setIsTrained] = useState<boolean>(true);

  const problemType = profile.problemType;
  const targetCol = profile.suggestedTarget;

  // Simulate training leaderboard
  const modelsLeaderboard = useMemo(() => {
    if (problemType === "Classification") {
      return [
        { name: "XGBoost Ensemble", metricName: "Accuracy", score: 0.942, precision: 0.93, recall: 0.94, f1: 0.935, status: "Optimal" },
        { name: "LightGBM Classifier", metricName: "Accuracy", score: 0.925, precision: 0.92, recall: 0.91, f1: 0.915, status: "Trained" },
        { name: "Random Forest", metricName: "Accuracy", score: 0.910, precision: 0.90, recall: 0.91, f1: 0.905, status: "Trained" },
        { name: "Deep Neural Network", metricName: "Accuracy", score: 0.887, precision: 0.87, recall: 0.89, f1: 0.880, status: "Trained" },
        { name: "Support Vector Machine", metricName: "Accuracy", score: 0.824, precision: 0.81, recall: 0.83, f1: 0.820, status: "Baseline" }
      ];
    } else {
      return [
        { name: "XGBoost Ensemble", metricName: "R-squared", score: 0.895, precision: null, recall: null, f1: null, rmse: 124.5, status: "Optimal" },
        { name: "LightGBM Regressor", metricName: "R-squared", score: 0.878, precision: null, recall: null, f1: null, rmse: 140.2, status: "Trained" },
        { name: "Random Forest Regressor", metricName: "R-squared", score: 0.862, precision: null, recall: null, f1: null, rmse: 151.0, status: "Trained" },
        { name: "Deep MLP Regressor", metricName: "R-squared", score: 0.835, precision: null, recall: null, f1: null, rmse: 178.4, status: "Trained" },
        { name: "Ridge Regression", metricName: "R-squared", score: 0.741, precision: null, recall: null, f1: null, rmse: 245.9, status: "Baseline" }
      ];
    }
  }, [problemType]);

  const activeModelStats = useMemo(() => {
    return modelsLeaderboard.find(m => m.name === selectedModel) || modelsLeaderboard[0];
  }, [selectedModel, modelsLeaderboard]);

  // SHAP Feature importance calculated from correlations to look realistic!
  const shapFeatures = useMemo(() => {
    return profile.columnProfiles
      .filter(col => col.name !== targetCol)
      .map(col => {
        // Find correlation to target
        const pair = profile.correlationMatrix.find(
          p => (p.colA === col.name && p.colB === targetCol) || (p.colA === targetCol && p.colB === col.name)
        );
        const absCorr = pair ? Math.abs(pair.correlation) : 0.1;
        return {
          feature: col.name,
          shapValue: Math.round((absCorr * 100 + Math.random() * 5) * 100) / 100
        };
      })
      .sort((a, b) => b.shapValue - a.shapValue)
      .slice(0, 8);
  }, [profile, targetCol]);

  // ROC Curve coordinate points for plotting!
  const rocPoints = [
    { fpr: 0.0, tpr: 0.0 },
    { fpr: 0.02, tpr: 0.45 },
    { fpr: 0.05, tpr: 0.75 },
    { fpr: 0.12, tpr: 0.88 },
    { fpr: 0.20, tpr: 0.94 },
    { fpr: 0.40, tpr: 0.97 },
    { fpr: 0.60, tpr: 0.99 },
    { fpr: 1.0, tpr: 1.0 }
  ];

  const triggerRetraining = () => {
    setIsTraining(true);
    setIsTrained(false);
    setTimeout(() => {
      setIsTraining(false);
      setIsTrained(true);
    }, 2000);
  };

  return (
    <div id="ml-view" className="space-y-8 animate-fade-in text-left">
      {/* Page Title */}
      <div>
        <h1 className="font-display font-extrabold text-3xl text-white tracking-tight">AutoML & Explainable AI (SHAP)</h1>
        <p className="text-xs sm:text-sm text-slate-400 font-light mt-1">
          Auto-train models and inspect predictive feature importances on <span className="font-mono text-indigo-400">{profile.name}</span>.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Leaderboard */}
        <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-6 lg:col-span-1 h-fit">
          <div className="flex justify-between items-center border-b border-white/5 pb-3">
            <h3 className="font-display font-bold text-sm text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-indigo-400" /> Leaderboard
            </h3>
            <span className="text-[10px] font-mono text-slate-500 uppercase">{problemType}</span>
          </div>

          <div className="space-y-3">
            {modelsLeaderboard.map((m, idx) => (
              <div
                key={idx}
                onClick={() => setSelectedModel(m.name)}
                className={`p-3.5 rounded-2xl border transition cursor-pointer text-left flex justify-between items-center ${
                  selectedModel === m.name
                    ? "bg-indigo-950/30 border-indigo-500/80 shadow-lg shadow-indigo-500/10"
                    : "bg-slate-900/30 border-white/5 hover:border-indigo-500/30"
                }`}
              >
                <div>
                  <h4 className="font-display font-bold text-xs text-slate-200">{m.name}</h4>
                  <div className="text-[9px] font-mono text-slate-500 uppercase mt-0.5">{m.status}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-extrabold text-white">{m.score.toFixed(3)}</div>
                  <div className="text-[9px] text-slate-500 font-mono">{m.metricName}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Retrain Action */}
          <button
            onClick={triggerRetraining}
            disabled={isTraining}
            className="w-full py-3 bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded-xl transition text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
          >
            {isTraining ? "Tuning Hyperparameters..." : "Re-Train All Ensembles"}
          </button>
        </div>

        {/* Right Columns: Explainable AI & SHAP */}
        <div className="lg:col-span-2 space-y-8">
          {isTraining ? (
            <div className="p-16 rounded-3xl bg-slate-950/40 border border-white/5 flex flex-col items-center justify-center min-h-[450px] space-y-4">
              <div className="w-12 h-12 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
              <div className="text-center">
                <h3 className="font-display font-bold text-sm text-white">Cross-Validating Pipelines...</h3>
                <p className="text-[10px] text-slate-500 font-mono mt-0.5">Running gradient-boosting iterations under extreme parameters.</p>
              </div>
            </div>
          ) : (
            <div className="space-y-8 animate-fade-in">
              {/* SHAP Feature Importance */}
              <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4">
                <div className="flex justify-between items-center border-b border-white/5 pb-4">
                  <div className="text-left">
                    <h3 className="font-display font-bold text-sm text-white">SHAP Feature Importance (Explainable AI)</h3>
                    <p className="text-[10px] text-slate-500 mt-0.5 font-mono">Model: {selectedModel} | Target: {targetCol}</p>
                  </div>
                  <span className="text-[10px] uppercase font-mono text-cyan-400 font-semibold bg-cyan-950/40 border border-cyan-900/60 px-2 py-0.5 rounded">
                    Mean |SHAP| Impact
                  </span>
                </div>

                <div className="h-[250px] w-full pt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={shapFeatures} layout="vertical" margin={{ top: 5, right: 10, left: 30, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                      <XAxis type="number" stroke="#64748b" fontSize={10} tickLine={false} />
                      <YAxis dataKey="feature" type="category" stroke="#64748b" fontSize={10} tickLine={false} />
                      <Tooltip contentStyle={{ backgroundColor: "#020617", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px", fontSize: "11px" }} />
                      <Bar dataKey="shapValue" fill="#8b5cf6" radius={[0, 4, 4, 0]} name="SHAP Impact" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Bottom Row: Evaluation matrices and ROC curves */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Confusion Matrix / Residuals */}
                <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4 text-left">
                  <h3 className="font-display font-bold text-sm text-white border-b border-white/5 pb-3">
                    {problemType === "Classification" ? "Prediction Confusion Matrix" : "Regression Metrics"}
                  </h3>

                  {problemType === "Classification" ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-2 font-mono text-xs text-center pt-2">
                        <div />
                        <div className="text-slate-500 font-bold uppercase tracking-wider text-[9px]">Pred Positive</div>
                        <div className="text-slate-500 font-bold uppercase tracking-wider text-[9px]">Pred Negative</div>

                        <div className="text-slate-500 text-left font-bold uppercase tracking-wider text-[9px] flex items-center">Actual Pos</div>
                        <div className="p-4 bg-indigo-950/40 border border-indigo-500/30 text-white rounded-xl">
                          <span className="font-extrabold text-base">84</span>
                          <div className="text-[8px] text-indigo-400 font-semibold mt-0.5">True Pos</div>
                        </div>
                        <div className="p-4 bg-slate-900/30 border border-white/5 text-slate-500 rounded-xl">
                          <span className="font-bold text-base">4</span>
                          <div className="text-[8px] text-slate-500 font-semibold mt-0.5">False Neg</div>
                        </div>

                        <div className="text-slate-500 text-left font-bold uppercase tracking-wider text-[9px] flex items-center">Actual Neg</div>
                        <div className="p-4 bg-slate-900/30 border border-white/5 text-slate-500 rounded-xl">
                          <span className="font-bold text-base">2</span>
                          <div className="text-[8px] text-slate-500 font-semibold mt-0.5">False Pos</div>
                        </div>
                        <div className="p-4 bg-indigo-950/40 border border-indigo-500/30 text-white rounded-xl">
                          <span className="font-extrabold text-base">112</span>
                          <div className="text-[8px] text-indigo-400 font-semibold mt-0.5">True Neg</div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3 font-mono text-xs pt-2">
                      <div className="flex justify-between p-2.5 bg-slate-900/30 border border-white/5 rounded-xl">
                        <span className="text-slate-400">RMSE Error Bounds</span>
                        <span className="text-white font-bold">{activeModelStats.rmse}</span>
                      </div>
                      <div className="flex justify-between p-2.5 bg-slate-900/30 border border-white/5 rounded-xl">
                        <span className="text-slate-400">Cross-Val Splits</span>
                        <span className="text-white font-bold">5 K-Folds</span>
                      </div>
                      <div className="flex justify-between p-2.5 bg-slate-900/30 border border-white/5 rounded-xl">
                        <span className="text-slate-400">Total Epoch Iterations</span>
                        <span className="text-white font-bold">350 trees</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* ROC Curve Chart */}
                <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4 text-left">
                  <h3 className="font-display font-bold text-sm text-white border-b border-white/5 pb-3">
                    ROC Accuracy Frontier
                  </h3>

                  <div className="h-[140px] w-full pt-2">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={rocPoints}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="fpr" stroke="#64748b" fontSize={9} label={{ value: "FPR", position: "insideBottom", offset: -5, fill: "#64748b" }} />
                        <YAxis stroke="#64748b" fontSize={9} label={{ value: "TPR", angle: -90, position: "insideLeft", offset: 10, fill: "#64748b" }} />
                        <Tooltip contentStyle={{ backgroundColor: "#020617", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "8px", fontSize: "10px" }} />
                        <Line type="monotone" dataKey="tpr" stroke="#10b981" strokeWidth={2.5} dot={false} name="Model Curve" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
