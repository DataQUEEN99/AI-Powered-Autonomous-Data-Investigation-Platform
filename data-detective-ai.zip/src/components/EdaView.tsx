/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { 
  ResponsiveContainer, BarChart, LineChart, AreaChart, ScatterChart,
  Bar, Line, Area, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend
} from "recharts";
import { Settings2 } from "lucide-react";
import { DatasetProfile } from "../types";

interface EdaViewProps {
  profile: DatasetProfile;
}

export default function EdaView({ profile }: EdaViewProps) {
  // Get list of columns
  const columns = useMemo(() => profile.columnProfiles.map(c => c.name), [profile]);
  const numericColumns = useMemo(() => profile.columnProfiles.filter(c => c.type === 'numeric').map(c => c.name), [profile]);

  // States for interactive bindings
  const [xAxisCol, setXAxisCol] = useState(columns[0]);
  const [yAxisCol, setYAxisCol] = useState(numericColumns[0] || columns[1]);
  const [chartType, setChartType] = useState<'bar' | 'line' | 'area' | 'scatter'>('bar');
  const [colorScheme, setColorScheme] = useState<string>("#6366f1");

  // Format data for recharts
  const chartData = useMemo(() => {
    // Return sample rows
    return profile.sampleData.slice(0, 30).map(row => {
      return {
        ...row,
        // Make sure values are ready
        xVal: row[xAxisCol],
        yVal: typeof row[yAxisCol] === 'number' ? row[yAxisCol] : parseFloat(row[yAxisCol]) || 0
      };
    });
  }, [profile, xAxisCol, yAxisCol]);

  return (
    <div id="eda-view" className="space-y-8 animate-fade-in text-left">
      {/* Page Title */}
      <div>
        <h1 className="font-display font-extrabold text-3xl text-white tracking-tight">Interactive EDA Lab</h1>
        <p className="text-xs sm:text-sm text-slate-400 font-light mt-1">
          Slice and plot numerical anchors of <span className="font-mono text-indigo-400">{profile.name}</span> instantly.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Controllers */}
        <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-6 lg:col-span-1 h-fit">
          <h3 className="font-display font-bold text-sm text-white flex items-center gap-2 border-b border-white/5 pb-3">
            <Settings2 className="w-4 h-4 text-indigo-400" /> Chart Controllers
          </h3>

          {/* Chart Type Selection */}
          <div className="space-y-2">
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Visualization Type</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => { setChartType('bar'); setColorScheme("#3b82f6"); }}
                className={`py-2 px-3 rounded-xl font-medium text-[11px] transition cursor-pointer text-center ${
                  chartType === 'bar' ? "bg-blue-600 text-white" : "bg-slate-900/50 text-slate-400 border border-white/5 hover:text-white"
                }`}
              >
                Bar Chart
              </button>
              <button
                onClick={() => { setChartType('line'); setColorScheme("#6366f1"); }}
                className={`py-2 px-3 rounded-xl font-medium text-[11px] transition cursor-pointer text-center ${
                  chartType === 'line' ? "bg-indigo-600 text-white" : "bg-slate-900/50 text-slate-400 border border-white/5 hover:text-white"
                }`}
              >
                Line Trend
              </button>
              <button
                onClick={() => { setChartType('area'); setColorScheme("#06b6d4"); }}
                className={`py-2 px-3 rounded-xl font-medium text-[11px] transition cursor-pointer text-center ${
                  chartType === 'area' ? "bg-cyan-600 text-white" : "bg-slate-900/50 text-slate-400 border border-white/5 hover:text-white"
                }`}
              >
                Area Fill
              </button>
              <button
                onClick={() => { setChartType('scatter'); setColorScheme("#22c55e"); }}
                className={`py-2 px-3 rounded-xl font-medium text-[11px] transition cursor-pointer text-center ${
                  chartType === 'scatter' ? "bg-emerald-600 text-white" : "bg-slate-900/50 text-slate-400 border border-white/5 hover:text-white"
                }`}
              >
                Scatter Plot
              </button>
            </div>
          </div>

          {/* X Axis Binding */}
          <div className="space-y-2">
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Bind X-Axis</label>
            <select
              value={xAxisCol}
              onChange={(e) => setXAxisCol(e.target.value)}
              className="w-full bg-slate-900 border border-white/5 text-xs text-white rounded-xl p-3 focus:outline-none focus:border-indigo-500 font-light cursor-pointer"
            >
              {columns.map((c, i) => (
                <option key={i} value={c}>{c}</option>
              ))}
            </select>
          </div>

          {/* Y Axis Binding */}
          <div className="space-y-2">
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Bind Y-Axis (Numeric)</label>
            <select
              value={yAxisCol}
              onChange={(e) => setYAxisCol(e.target.value)}
              className="w-full bg-slate-900 border border-white/5 text-xs text-white rounded-xl p-3 focus:outline-none focus:border-indigo-500 font-light cursor-pointer"
            >
              {numericColumns.map((c, i) => (
                <option key={i} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Dynamic Recharts Canvas */}
        <div className="lg:col-span-3 p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4">
          <div className="flex justify-between items-center border-b border-white/5 pb-4">
            <div className="text-left">
              <h3 className="font-display font-bold text-sm text-white">Dynamic Analytics Plot</h3>
              <p className="text-[10px] font-mono text-slate-500 mt-0.5">X: {xAxisCol} | Y: {yAxisCol}</p>
            </div>
            <span className="text-[10px] uppercase font-mono text-indigo-400 font-semibold bg-indigo-950/40 border border-indigo-900/40 px-2 py-0.5 rounded">
              30 Row preview
            </span>
          </div>

          <div className="h-[380px] w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              {chartType === 'bar' ? (
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="xVal" stroke="#64748b" fontSize={10} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: "#020617", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px", fontSize: "11px" }} />
                  <Bar dataKey="yVal" fill={colorScheme} radius={[4, 4, 0, 0]} name={yAxisCol} />
                </BarChart>
              ) : chartType === 'line' ? (
                <LineChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="xVal" stroke="#64748b" fontSize={10} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: "#020617", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px", fontSize: "11px" }} />
                  <Line type="monotone" dataKey="yVal" stroke={colorScheme} strokeWidth={2.5} dot={{ r: 4 }} name={yAxisCol} />
                </LineChart>
              ) : chartType === 'area' ? (
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                  <defs>
                    <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={colorScheme} stopOpacity={0.4} />
                      <stop offset="95%" stopColor={colorScheme} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="xVal" stroke="#64748b" fontSize={10} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: "#020617", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px", fontSize: "11px" }} />
                  <Area type="monotone" dataKey="yVal" stroke={colorScheme} strokeWidth={2} fillOpacity={1} fill="url(#areaGrad)" name={yAxisCol} />
                </AreaChart>
              ) : (
                <ScatterChart margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="xVal" name={xAxisCol} stroke="#64748b" fontSize={10} tickLine={false} />
                  <YAxis dataKey="yVal" name={yAxisCol} stroke="#64748b" fontSize={10} tickLine={false} />
                  <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ backgroundColor: "#020617", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px", fontSize: "11px" }} />
                  <Scatter name="Clustering Group" data={chartData} fill={colorScheme} />
                </ScatterChart>
              )}
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
