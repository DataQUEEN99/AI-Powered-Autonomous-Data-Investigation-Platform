/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Search, ShieldAlert, CheckCircle2, AlertCircle, 
  HelpCircle, ArrowRight, RefreshCcw, User, 
  Sparkles, Award, FileText, Compass, HardHat
} from "lucide-react";
import { DatasetProfile, CrimeContext } from "../types";

interface DetectiveEngineViewProps {
  profile: DatasetProfile;
  initialCrimeContext: CrimeContext | null;
}

export default function DetectiveEngineView({ profile, initialCrimeContext }: DetectiveEngineViewProps) {
  const [clue, setClue] = useState("");
  const [caseData, setCaseData] = useState<CrimeContext | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Load initial case if provided, else run an automatic initial investigation
  useEffect(() => {
    if (initialCrimeContext) {
      setCaseData(initialCrimeContext);
    } else {
      triggerInquest();
    }
  }, [profile, initialCrimeContext]);

  const triggerInquest = async (customClue?: string) => {
    setIsLoading(true);
    setSuccessMsg(null);
    try {
      const response = await fetch("/api/investigate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profile,
          contextPrompt: customClue || ""
        })
      });

      if (!response.ok) {
        throw new Error("Sleuth network failure. The trail went cold.");
      }

      const report = await response.json();
      setCaseData(report);
      if (customClue) {
        setSuccessMsg("Investigation redirected successfully! Clue incorporated into verdict.");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clue.trim()) return;
    triggerInquest(clue);
  };

  return (
    <div id="detective-engine-view" className="space-y-8 animate-fade-in text-left">
      {/* Page Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-extrabold text-3xl text-white tracking-tight flex items-center gap-2">
            🕵️ Sherlock Inquest Engine
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-light mt-1">
            Transforming columns and numbers into structured criminal investigations.
          </p>
        </div>
        {caseData && (
          <div className="p-3 bg-slate-950/60 border border-white/5 rounded-2xl flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <div className="font-mono text-xs text-slate-300">
              CASE LOGGED: <span className="text-indigo-400 font-bold">{caseData.caseNumber}</span>
            </div>
          </div>
        )}
      </div>

      {isLoading ? (
        <div className="glass-panel p-16 rounded-3xl flex flex-col items-center justify-center space-y-6 bg-slate-950/40 min-h-[400px]">
          <div className="relative flex items-center justify-center">
            <div className="w-16 h-16 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
            <Compass className="w-6 h-6 text-indigo-400 absolute animate-pulse" />
          </div>
          <div className="space-y-2 text-center">
            <h3 className="font-display font-bold text-lg text-white">Synthesizing Crime Dossier...</h3>
            <p className="text-xs text-slate-400 font-mono">Cross-referencing outliers, scoring confidence bounds, and draft writing final verdict.</p>
          </div>
        </div>
      ) : caseData ? (
        <div className="space-y-8">
          {/* Main Dossier Summary Header */}
          <div className="relative p-8 rounded-3xl bg-gradient-to-br from-slate-950/90 to-[#0c0f24] border border-indigo-950/60 shadow-xl overflow-hidden">
            {/* Glowing active light ring */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full filter blur-3xl pointer-events-none" />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Crime and Scene info */}
              <div className="lg:col-span-2 space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-950/60 border border-red-900/60 text-red-400 text-[10px] font-bold font-mono rounded-full uppercase tracking-wider">
                  Crime Target: {caseData.crime}
                </div>
                <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white tracking-tight">
                  {caseData.crime}
                </h2>
                <p className="text-xs text-slate-400 leading-relaxed font-light">
                  <span className="font-semibold text-slate-300">Crime Scene Context:</span> This investigation stems from patterns recorded within the <span className="text-white font-mono">{caseData.scene}</span> pipeline using historical vectors.
                </p>
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 pt-1 font-mono">
                  <span>Sleuth Confidence:</span>
                  <div className="flex items-center gap-1.5">
                    <div className="w-24 h-2 bg-slate-900 rounded-full overflow-hidden border border-white/5">
                      <div className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400" style={{ width: `${caseData.confidence}%` }} />
                    </div>
                    <span className="text-cyan-400 font-bold">{caseData.confidence}%</span>
                  </div>
                </div>
              </div>

              {/* Prime Suspect Indicator Card */}
              <div className="p-6 rounded-2xl bg-[#070b1a] border border-white/5 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-red-400 font-bold uppercase block">PRIME SUSPECT IDENTIFIED</span>
                  <h3 className="font-display font-bold text-xl text-white mt-2 truncate" title={caseData.primeSuspect}>
                    {caseData.primeSuspect}
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-1 font-light leading-relaxed">
                    Most influential mathematical driver isolated behind target variance.
                  </p>
                </div>
                <div className="text-[10px] text-slate-500 font-mono mt-4 flex items-center justify-between">
                  <span>Verdict Status</span>
                  <span className="text-emerald-400 font-bold bg-emerald-950/40 border border-emerald-900/40 px-2 py-0.5 rounded">CONVICTED</span>
                </div>
              </div>
            </div>
          </div>

          {/* Evidence List & Suspects Lineup */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left: Secure Evidence List */}
            <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-6">
              <h3 className="font-display font-bold text-lg text-white flex items-center gap-2 border-b border-white/5 pb-3">
                <FileText className="w-5 h-5 text-indigo-400" /> Statistical Forensic Evidence
              </h3>

              <div className="space-y-4">
                {caseData.evidence.map((ev, idx) => (
                  <div key={idx} className="p-4 bg-slate-900/40 border border-white/5 rounded-2xl flex gap-3.5 items-start">
                    <div className="w-6 h-6 rounded-lg bg-indigo-950/80 border border-indigo-900/60 text-indigo-400 flex items-center justify-center font-mono text-xs font-bold shrink-0">
                      {idx + 1}
                    </div>
                    <p className="text-xs text-slate-300 font-light leading-relaxed">{ev}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Suspects Lineup */}
            <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-6">
              <h3 className="font-display font-bold text-lg text-white flex items-center gap-2 border-b border-white/5 pb-3">
                <ShieldAlert className="w-5 h-5 text-indigo-400" /> Candidate Culprits Lineup
              </h3>

              <div className="space-y-3">
                {caseData.suspects.map((sus, idx) => {
                  let alertBg = "bg-yellow-950/25 border-yellow-900/30 text-yellow-400";
                  if (sus.threatLevel === "CRITICAL") {
                    alertBg = "bg-red-950/25 border-red-900/30 text-red-400";
                  } else if (sus.threatLevel === "Low") {
                    alertBg = "bg-slate-900/40 border-white/5 text-slate-400";
                  }

                  return (
                    <div key={idx} className="p-4 bg-slate-900/20 border border-white/5 rounded-2xl flex justify-between items-center gap-4 text-left">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-display font-bold text-sm text-white">{sus.name}</h4>
                          <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${alertBg}`}>
                            {sus.threatLevel}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 font-light mt-1.5 leading-relaxed">{sus.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Deep Verdict Narrative */}
          <div className="p-8 rounded-3xl bg-slate-950/40 border border-white/5 text-left space-y-4 relative">
            {/* Corner illustration badge */}
            <div className="absolute top-6 right-6 w-12 h-12 rounded-2xl bg-indigo-950/40 border border-indigo-900/40 text-indigo-400 flex items-center justify-center font-bold">
              <Sparkles className="w-5 h-5" />
            </div>

            <h3 className="font-display font-bold text-lg text-white border-b border-white/5 pb-3">
              Sherlock AI's Investigative Verdict
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 font-light leading-relaxed whitespace-pre-line pt-2">
              {caseData.verdict}
            </p>
          </div>

          {/* Recommended Remediation Actions */}
          <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4 text-left">
            <h3 className="font-display font-bold text-lg text-white border-b border-white/5 pb-3">
              Strategic Remediation Tactics
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              {caseData.actions.map((act, idx) => (
                <div key={idx} className="p-4 rounded-xl border border-emerald-950 bg-emerald-950/15 text-left space-y-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="text-[10px] font-bold font-mono tracking-wider text-emerald-400 uppercase">RECOMMENDED</span>
                  </div>
                  <p className="text-xs text-slate-300 font-light leading-relaxed">{act}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Redirect Clue Form */}
          <div className="p-6 rounded-3xl bg-[#090e24] border border-indigo-950/60 text-left space-y-4">
            <h3 className="font-display font-bold text-base text-white">Direct the Investigation</h3>
            <p className="text-xs text-slate-400 font-light leading-relaxed">
              Do you have a specific theory or contextual clue? (e.g., "Analyze the impact of ad spend in April", "Could marketing budget be a suspect?"). Provide it below to redirect the AI detective.
            </p>

            <form onSubmit={handleClueSubmit} className="flex gap-3">
              <input 
                type="text" 
                placeholder="Type your contextual clue or suspect theory..."
                value={clue}
                onChange={(e) => setClue(e.target.value)}
                className="flex-1 bg-slate-950/80 text-xs text-slate-200 border border-white/10 rounded-xl px-4 focus:outline-none focus:border-indigo-500 font-light"
              />
              <button 
                id="btn-re-examine"
                type="submit"
                disabled={isLoading}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white font-medium text-xs rounded-xl shadow-lg shadow-indigo-600/20 transition shrink-0 flex items-center gap-2 cursor-pointer font-semibold"
              >
                Re-Examine <RefreshCcw className="w-3.5 h-3.5 animate-spin-slow" />
              </button>
            </form>

            {successMsg && (
              <div className="p-3 bg-emerald-950/30 border border-emerald-900/30 text-emerald-300 text-xs rounded-xl flex items-center gap-2 font-light">
                <CheckCircle2 className="w-4 h-4 shrink-0" /> {successMsg}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="text-slate-400 font-light py-12 text-center text-xs font-mono">
          Could not establish context files. Please return to the Upload screen.
        </div>
      )}
    </div>
  );
}
