/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import LandingPage from "./components/LandingPage";
import Sidebar from "./components/Sidebar";
import UploadView from "./components/UploadView";
import ProfileView from "./components/ProfileView";
import DetectiveEngineView from "./components/DetectiveEngineView";
import EdaView from "./components/EdaView";
import MachineLearningView from "./components/MachineLearningView";
import ForecastView from "./components/ForecastView";
import ChatView from "./components/ChatView";
import ReportGeneratorView from "./components/ReportGeneratorView";
import AdminPanelView from "./components/AdminPanelView";
import SettingsView from "./components/SettingsView";
import { DatasetProfile, CrimeContext, ViewType } from "./types";
import { 
  Bell, Search, Sparkles, FolderKanban, 
  HelpCircle, ShieldCheck, Database, Calendar
} from "lucide-react";

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('landing');
  const [activeDataset, setActiveDataset] = useState<DatasetProfile | null>(null);
  const [activeCrimeContext, setActiveCrimeContext] = useState<CrimeContext | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Quick launch for preloaded demo dataset from Hero
  const triggerDemoDataset = async () => {
    setIsLoading(true);
    setCurrentView('upload');
    try {
      const res = await fetch("/api/datasets/ecommerce_decline");
      if (res.ok) {
        const payload = await res.json();
        setActiveDataset(payload.profile);
        setActiveCrimeContext(payload.crimeContext);
        setCurrentView('dashboard');
      }
    } catch (err) {
      console.error("Demo trigger failed:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDatasetLoaded = (profile: DatasetProfile, crimeContext?: any) => {
    setActiveDataset(profile);
    if (crimeContext) {
      setActiveCrimeContext(crimeContext);
    } else {
      setActiveCrimeContext(null);
    }
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setActiveDataset(null);
    setActiveCrimeContext(null);
    setCurrentView('landing');
  };

  // If we are on the landing page, render it
  if (currentView === 'landing') {
    return (
      <LandingPage 
        onStart={() => setCurrentView('upload')} 
        onTryDemo={triggerDemoDataset} 
      />
    );
  }

  return (
    <div className="flex h-screen w-screen bg-[#050816] text-slate-100 overflow-hidden font-sans">
      {/* Premium Sidebar */}
      <Sidebar 
        currentView={currentView} 
        onViewChange={setCurrentView} 
        activeDatasetName={activeDataset ? activeDataset.name : null}
        onLogout={handleLogout}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Decorative dynamic ambient glow */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-indigo-500/5 rounded-full filter blur-[120px] pointer-events-none" />

        {/* Top Navbar */}
        <header className="h-16 border-b border-white/5 px-8 flex justify-between items-center bg-slate-950/40 backdrop-blur-md shrink-0 relative z-10">
          {/* Breadcrumb / Title area */}
          <div className="flex items-center gap-2">
            <FolderKanban className="w-4 h-4 text-slate-500" />
            <span className="text-xs text-slate-400 font-mono">Case Archive</span>
            <span className="text-xs text-slate-600 font-mono">/</span>
            <span className="text-xs font-semibold font-mono text-indigo-400 capitalize">
              {currentView === 'eda' ? 'EDA visual laboratory' : currentView === 'ml' ? 'AutoML Ensembles' : currentView}
            </span>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-4">
            {/* System Clock */}
            <div className="hidden md:flex items-center gap-1.5 px-3 py-1 bg-slate-900/40 border border-white/5 rounded-xl font-mono text-[10px] text-slate-400">
              <Calendar className="w-3.5 h-3.5" />
              <span>UTC 2026-06-28</span>
            </div>

            {/* Notification Bell */}
            <button 
              onClick={() => alert("Notification Center: All forensic pipelines running optimal.")}
              className="p-2 border border-white/5 hover:border-indigo-500/30 bg-slate-900/20 hover:text-indigo-400 rounded-xl transition relative cursor-pointer"
            >
              <Bell className="w-4 h-4 text-slate-400 hover:text-indigo-400" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-indigo-500 rounded-full" />
            </button>
          </div>
        </header>

        {/* Dynamic Inner Workspace Contents */}
        <main className="flex-1 p-8 overflow-y-auto relative z-10">
          <div className="max-w-6xl mx-auto h-full">
            
            {/* 'dashboard' overview tab */}
            {currentView === 'dashboard' && (
              <div className="space-y-8 animate-fade-in text-left">
                {/* Dashboard Jumbotron Welcome */}
                <div className="p-8 rounded-3xl bg-gradient-to-br from-indigo-950/45 to-[#0b0e24] border border-indigo-950/60 shadow-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/5 rounded-full filter blur-3xl pointer-events-none" />
                  <div className="max-w-xl space-y-3">
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-950/60 border border-indigo-900/60 text-indigo-300 text-[10px] font-bold font-mono rounded-full uppercase tracking-wider">
                      INVESTIGATOR HOME
                    </div>
                    <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white tracking-tight leading-tight">
                      Good Day, Investigator Aman
                    </h2>
                    <p className="text-xs text-slate-400 leading-relaxed font-light">
                      Welcome to your secure sandbox data laboratory. We have isolated core regression factors and initialized AutoML pipelines. Launch an AI Detective Case or inspect automatic chart layers.
                    </p>
                  </div>
                </div>

                {/* Grid Overview Info */}
                {activeDataset ? (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Active File Card */}
                    <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4 flex flex-col justify-between">
                      <div>
                        <div className="p-3 bg-gradient-to-tr from-indigo-500 to-blue-600 rounded-2xl w-fit shadow shadow-indigo-500/20">
                          <Database className="w-5 h-5 text-white" />
                        </div>
                        <h3 className="font-display font-bold text-sm text-slate-200 mt-4">Active Evidence Spreadsheet</h3>
                        <p className="text-xs font-mono text-slate-400 mt-1 truncate">{activeDataset.name}</p>
                      </div>
                      <button
                        onClick={() => setCurrentView('profile')}
                        className="w-full py-2.5 bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs rounded-xl font-semibold transition cursor-pointer"
                      >
                        Inspect Micro-Profile
                      </button>
                    </div>

                    {/* AI Detective Card */}
                    <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4 flex flex-col justify-between">
                      <div>
                        <div className="p-3 bg-gradient-to-tr from-cyan-500 to-emerald-500 rounded-2xl w-fit shadow shadow-cyan-500/20">
                          <Search className="w-5 h-5 text-white" />
                        </div>
                        <h3 className="font-display font-bold text-sm text-slate-200 mt-4">Sherlock AI Inquest</h3>
                        <p className="text-xs text-slate-400 mt-1 font-light leading-relaxed">
                          Run our natural language model to isolate suspects and deliver final business verdicts.
                        </p>
                      </div>
                      <button
                        onClick={() => setCurrentView('detective')}
                        className="w-full py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs rounded-xl font-semibold transition shadow-md cursor-pointer"
                      >
                        Open CSI Docket
                      </button>
                    </div>

                    {/* Quality Meter Mini Card */}
                    <div className="p-6 rounded-3xl bg-slate-950/40 border border-white/5 space-y-4 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500">Quality Health</span>
                          <span className="text-xs text-indigo-400 font-bold font-mono">{activeDataset.healthScore}%</span>
                        </div>
                        <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden mt-3 border border-white/5">
                          <div className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400" style={{ width: `${activeDataset.healthScore}%` }} />
                        </div>
                        <p className="text-xs text-slate-400 mt-4 font-light leading-relaxed">
                          We mapped {activeDataset.columnProfiles.length} parameters with {activeDataset.outliersCount} outliers highlighted.
                        </p>
                      </div>
                      <button
                        onClick={() => setCurrentView('ml')}
                        className="w-full py-2.5 bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs rounded-xl font-semibold transition cursor-pointer"
                      >
                        Launch AutoML Pipeline
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-12 text-center text-slate-400 font-light text-xs font-mono">
                    Please upload a spreadsheet to populate your Investigator dashboard.
                  </div>
                )}
              </div>
            )}

            {/* Injected modular analytical views */}
            {currentView === 'upload' && (
              <UploadView 
                onDatasetLoaded={handleDatasetLoaded} 
                isLoading={isLoading}
                setIsLoading={setIsLoading}
              />
            )}

            {currentView === 'profile' && activeDataset && (
              <ProfileView profile={activeDataset} />
            )}

            {currentView === 'detective' && activeDataset && (
              <DetectiveEngineView 
                profile={activeDataset} 
                initialCrimeContext={activeCrimeContext}
              />
            )}

            {currentView === 'eda' && activeDataset && (
              <EdaView profile={activeDataset} />
            )}

            {currentView === 'ml' && activeDataset && (
              <MachineLearningView profile={activeDataset} />
            )}

            {currentView === 'forecast' && activeDataset && (
              <ForecastView profile={activeDataset} />
            )}

            {currentView === 'chat' && activeDataset && (
              <ChatView profile={activeDataset} />
            )}

            {currentView === 'reports' && activeDataset && (
              <ReportGeneratorView profile={activeDataset} />
            )}

            {currentView === 'admin' && (
              <AdminPanelView />
            )}

            {currentView === 'settings' && (
              <SettingsView />
            )}

          </div>
        </main>
      </div>
    </div>
  );
}
