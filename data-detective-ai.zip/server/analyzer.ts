/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Custom dataset structures and high-fidelity mock data for instant demos
export interface DatasetProfile {
  name: string;
  rows: number;
  columns: number;
  memoryKb: number;
  missingValues: number;
  duplicateRows: number;
  outliersCount: number;
  healthScore: number;
  correlationScore: number;
  columnProfiles: ColumnProfile[];
  correlationMatrix: CorrelationPair[];
  sampleData: Record<string, any>[];
  problemType: 'Classification' | 'Regression' | 'Clustering' | 'Forecasting';
  suggestedTarget: string;
}

export interface ColumnProfile {
  name: string;
  type: 'numeric' | 'categorical' | 'date';
  missingCount: number;
  missingPercentage: number;
  uniqueValues: number;
  min?: number;
  max?: number;
  mean?: number;
  stdDev?: number;
}

export interface CorrelationPair {
  colA: string;
  colB: string;
  correlation: number;
}

// ----------------------------------------------------------------------
// High-Fidelity Preloaded Datasets
// ----------------------------------------------------------------------
export const PRELOADED_DATASETS: Record<string, { name: string; description: string; data: string; crimeContext: any }> = {
  ecommerce_decline: {
    name: "E-Commerce Revenue Decline Case",
    description: "Investigate a sudden 20% drop in revenue across retail channels in Q2.",
    crimeContext: {
      caseNumber: "CASE-DD-2026-0412",
      crime: "Revenue Declined by 20%",
      scene: "E-Commerce Digital Channel & Fulfillment Centers",
      evidence: [
        "Ad Spend increased by 15%, but Conversion Rate dropped from 3.2% to 1.8%.",
        "Out-of-Stock events spiked by 240% in the Regional Fulfillment Center in the North.",
        "Average customer review score fell from 4.6 to 3.8 stars in the North region.",
        "High correlation (-0.84) between Out_of_Stock_Events and Customer_Satisfaction."
      ],
      suspects: [
        { name: "Marketing Budget Misallocation", description: "Wasting ad budget on products out of stock.", threatLevel: "Medium" },
        { name: "Inventory Stockouts & Supply Delays", description: "Failing to replenish top-selling items.", threatLevel: "CRITICAL" },
        { name: "Competitor Price Slashed", description: "Competitors offering massive discounts.", threatLevel: "Low" }
      ],
      primeSuspect: "Inventory Stockouts & Supply Delays",
      confidence: 94,
      verdict: "A massive bottleneck in supply replenishment led to 240% more out-of-stock events. Marketing campaigns continued to drive traffic to these out-of-stock item pages, resulting in frustration, a 43% drop in Conversion Rate, and subsequent customer churn in Region North.",
      actions: [
        "Implement automated inventory threshold alerts tied directly to live ad spend triggers (pause ads for out-of-stock items).",
        "Diversify supplier base in the North Region to reduce fulfillment delay.",
        "Initiate a customer retention campaign offering 15% discounts to impacted users."
      ]
    },
    data: `Date,Sales,Traffic_Count,Conversion_Rate,Average_Order_Value,Ad_Spend,Region,Out_Of_Stock_Events,Customer_Satisfaction
2026-01-01,120000,50000,2.4,100,5000,North,1,4.6
2026-01-08,125000,52000,2.4,100,5100,North,2,4.5
2026-01-15,123000,51000,2.4,101,5000,North,1,4.7
2026-01-22,128000,53000,2.4,100,5200,North,3,4.6
2026-02-01,135000,55000,2.5,98,5500,North,1,4.5
2026-02-08,138000,56000,2.5,99,5600,North,2,4.6
2026-02-15,134000,54000,2.5,99,5400,North,2,4.5
2026-02-22,141000,57000,2.5,99,5800,North,3,4.6
2026-03-01,152000,60000,2.5,101,6500,North,2,4.4
2026-03-08,155000,62000,2.5,100,6700,North,1,4.5
2026-03-15,148000,59000,2.5,100,6300,North,3,4.4
2026-03-22,159000,63000,2.5,101,6900,North,2,4.5
2026-04-01,142000,65000,2.2,99,7500,North,8,4.1
2026-04-08,131000,68000,1.9,101,8000,North,14,3.9
2026-04-15,122000,70000,1.7,102,8200,North,19,3.7
2026-04-22,115000,72000,1.6,100,8500,North,24,3.5
2026-05-01,108000,75000,1.4,103,9000,North,28,3.4
2026-05-08,102000,76000,1.3,103,9200,North,31,3.3
2026-05-15,98000,78000,1.3,101,9500,North,35,3.2
2026-05-22,95000,80000,1.2,99,10000,North,38,3.1
2026-06-01,92000,82000,1.1,102,10500,North,42,3.0
2026-06-08,89000,84000,1.1,101,10800,North,45,2.9
2026-06-15,86000,85000,1.0,101,11000,North,47,2.8
2026-06-22,81000,88000,0.9,102,11500,North,51,2.7`
  },
  saas_churn: {
    name: "SaaS Customer Churn Anomaly",
    description: "Analyze customer usage data to crack why enterprise renewals plummeted in the west.",
    crimeContext: {
      caseNumber: "CASE-DD-2026-9051",
      crime: "Enterprise Renewal Rate Dropped to 62%",
      scene: "Customer Success Dashboard & Support Escalation logs",
      evidence: [
        "Support Ticket Response Delay doubled from average 12 minutes to 46 minutes in the West region.",
        "Average Usage Hours fell by 35% for clients experiencing response delays > 30 mins.",
        "West NPS scores recorded an all-time low of -12 compared to +45 in East region.",
        "Correlation between Response_Delay_Min and Churn_Status is 0.78."
      ],
      suspects: [
        { name: "Product Instability / Bugs", description: "Frequent server timeouts frustrating active teams.", threatLevel: "Low" },
        { name: "Support Staff Burnout & Delays", description: "Understaffed regional support during peak business hours.", threatLevel: "CRITICAL" },
        { name: "Price Increase Backlash", description: "Renewal pricing hike pushing buyers to competitors.", threatLevel: "Medium" }
      ],
      primeSuspect: "Support Staff Burnout & Delays",
      confidence: 89,
      verdict: "High technical support queue delays (averaging 46 minutes) led to critical issues remaining unsolved for active enterprise clients in West. Out of frustration, their Monthly Usage Hours crashed, culminating in an unprecedented wave of account cancellations.",
      actions: [
        "Reallocate 3 senior support reps to the West timezone coverage immediately.",
        "Set up an automated SLA escalation trigger that alerts managers if enterprise tickets go unanswered for > 15 minutes.",
        "Implement AI support bots to triage basic issues and reduce queue load by 40%."
      ]
    },
    data: `CustomerID,Subscription_Tier,Monthly_Usage_Hours,Support_Tickets_Opened,Response_Delay_Min,Churn_Status,Last_Active_Days_Ago,Net_Promoter_Score
1001,Enterprise,120,2,8,0,2,80
1002,Enterprise,135,1,5,0,1,85
1003,Professional,45,3,12,0,3,70
1004,Basic,15,4,25,1,14,40
1005,Enterprise,140,2,6,0,1,90
1006,Enterprise,110,5,38,1,4,30
1007,Professional,85,3,15,0,2,75
1008,Enterprise,125,1,9,0,1,85
1009,Professional,20,6,45,1,8,25
1010,Enterprise,130,2,7,0,1,80
1011,Basic,12,3,28,1,15,35
1012,Enterprise,95,7,49,1,5,20
1013,Professional,78,2,11,0,2,80
1014,Enterprise,150,1,5,0,1,95
1015,Enterprise,65,8,52,1,12,15
1016,Professional,82,3,14,0,3,70
1017,Enterprise,115,2,8,0,1,85
1018,Basic,8,4,35,1,19,30
1019,Enterprise,70,6,42,1,6,25
1020,Enterprise,142,1,6,0,1,90
1021,Professional,90,2,10,0,2,80
1022,Enterprise,55,9,55,1,10,10
1023,Basic,18,2,22,0,4,65
1024,Enterprise,138,2,7,0,1,85`
  }
};

// Simple utility to parse CSV formatted text into rows and columns
export function parseCSV(csvText: string): Record<string, any>[] {
  const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);
  if (lines.length === 0) return [];

  // Robust CSV splitting handling quotes
  const parseLine = (line: string): string[] => {
    const result: string[] = [];
    let current = "";
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = "";
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  };

  const headers = parseLine(lines[0]);
  const data: Record<string, any>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = parseLine(lines[i]);
    if (values.length !== headers.length) continue; // Skip malformed rows
    
    const row: Record<string, any> = {};
    for (let j = 0; j < headers.length; j++) {
      const val = values[j];
      // Convert to number if numeric
      if (val === "" || val === undefined || val === null) {
        row[headers[j]] = null;
      } else if (!isNaN(Number(val))) {
        row[headers[j]] = Number(val);
      } else if (val.toLowerCase() === "true" || val.toLowerCase() === "false") {
        row[headers[j]] = val.toLowerCase() === "true";
      } else {
        row[headers[j]] = val;
      }
    }
    data.push(row);
  }

  return data;
}

// ----------------------------------------------------------------------
// Statistical Profile Generator
// ----------------------------------------------------------------------
export function generateDatasetProfile(fileName: string, data: Record<string, any>[]): DatasetProfile {
  if (data.length === 0) {
    throw new Error("Dataset is empty.");
  }

  const columns = Object.keys(data[0]);
  const rowsCount = data.length;
  const memoryKb = Math.round((rowsCount * columns.length * 8) / 1024);

  let missingValues = 0;
  let duplicateRows = 0;
  let outliersCount = 0;

  // Track unique row signatures to count duplicates
  const signatures = new Set<string>();
  data.forEach(row => {
    const sig = JSON.stringify(row);
    if (signatures.has(sig)) {
      duplicateRows++;
    } else {
      signatures.add(sig);
    }
  });

  // Calculate missing values and generate column profiles
  const columnProfiles: ColumnProfile[] = columns.map(col => {
    let missingCol = 0;
    const uniqueVals = new Set<any>();
    const numericVals: number[] = [];
    let isDate = true;

    data.forEach(row => {
      const val = row[col];
      if (val === undefined || val === null || val === "") {
        missingCol++;
        missingValues++;
      } else {
        uniqueVals.add(val);
        if (typeof val === "number") {
          numericVals.push(val);
          isDate = false;
        } else {
          // check if it's a date
          if (isDate && isNaN(Date.parse(val))) {
            isDate = false;
          }
        }
      }
    });

    const isNumeric = numericVals.length > data.length * 0.4; // Majority are numbers
    const type = isNumeric ? 'numeric' : (isDate && data.length > 2 ? 'date' : 'categorical');

    const profile: ColumnProfile = {
      name: col,
      type: type,
      missingCount: missingCol,
      missingPercentage: Math.round((missingCol / rowsCount) * 100),
      uniqueValues: uniqueVals.size
    };

    if (type === 'numeric' && numericVals.length > 0) {
      numericVals.sort((a, b) => a - b);
      const min = numericVals[0];
      const max = numericVals[numericVals.length - 1];
      const sum = numericVals.reduce((acc, v) => acc + v, 0);
      const mean = sum / numericVals.length;

      // Std dev
      const variance = numericVals.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / numericVals.length;
      const stdDev = Math.sqrt(variance);

      // Outliers using IQR
      const q1 = numericVals[Math.floor(numericVals.length * 0.25)] || min;
      const q3 = numericVals[Math.floor(numericVals.length * 0.75)] || max;
      const iqr = q3 - q1;
      const lowerBound = q1 - 1.5 * iqr;
      const upperBound = q3 + 1.5 * iqr;

      const colOutliers = numericVals.filter(v => v < lowerBound || v > upperBound).length;
      outliersCount += colOutliers;

      profile.min = Math.round(min * 100) / 100;
      profile.max = Math.round(max * 100) / 100;
      profile.mean = Math.round(mean * 100) / 100;
      profile.stdDev = Math.round(stdDev * 100) / 100;
    }

    return profile;
  });

  // Calculate correlations between numeric columns
  const numericColumns = columnProfiles.filter(p => p.type === 'numeric').map(p => p.name);
  const correlationMatrix: CorrelationPair[] = [];
  let maxCorrAbsoluteSum = 0;
  let corrCount = 0;

  for (let i = 0; i < numericColumns.length; i++) {
    for (let j = i; j < numericColumns.length; j++) {
      const colA = numericColumns[i];
      const colB = numericColumns[j];

      if (colA === colB) {
        correlationMatrix.push({ colA, colB, correlation: 1 });
        continue;
      }

      // Calculate Pearson correlation
      const valsA: number[] = [];
      const valsB: number[] = [];
      data.forEach(row => {
        if (typeof row[colA] === 'number' && typeof row[colB] === 'number') {
          valsA.push(row[colA]);
          valsB.push(row[colB]);
        }
      });

      if (valsA.length > 1) {
        const meanA = valsA.reduce((sum, v) => sum + v, 0) / valsA.length;
        const meanB = valsB.reduce((sum, v) => sum + v, 0) / valsB.length;

        let num = 0;
        let denA = 0;
        let denB = 0;

        for (let k = 0; k < valsA.length; k++) {
          const diffA = valsA[k] - meanA;
          const diffB = valsB[k] - meanB;
          num += diffA * diffB;
          denA += diffA * diffA;
          denB += diffB * diffB;
        }

        const r = denA && denB ? num / Math.sqrt(denA * denB) : 0;
        const roundedR = Math.round(r * 100) / 100;
        correlationMatrix.push({ colA, colB, correlation: roundedR });
        correlationMatrix.push({ colA: colB, colB: colA, correlation: roundedR });

        maxCorrAbsoluteSum += Math.abs(roundedR);
        corrCount++;
      }
    }
  }

  // Health Score computation (0 - 100)
  // Deductions for missing cells percentage, duplicates, outliers
  const totalCells = rowsCount * columns.length;
  const missingPct = missingValues / totalCells;
  const duplicatePct = duplicateRows / rowsCount;
  const outlierPct = outliersCount / totalCells;

  let healthScore = 100 - (missingPct * 150) - (duplicatePct * 100) - (outlierPct * 50);
  healthScore = Math.max(20, Math.min(100, Math.round(healthScore)));

  // Correlation Score (Higher is stronger relations found, meaning detective can work better!)
  const correlationScore = corrCount > 0 ? Math.round((maxCorrAbsoluteSum / corrCount) * 100) : 40;

  // Determine ML problem type and target suggestion
  let problemType: 'Classification' | 'Regression' | 'Clustering' | 'Forecasting' = 'Clustering';
  let suggestedTarget = "";

  const hasDate = columnProfiles.some(p => p.type === 'date');
  const numericCount = numericColumns.length;

  // Let's find columns representing flags/status/target/churn
  const targetKeywords = ['churn', 'status', 'attrition', 'outcome', 'target', 'label', 'class', 'sold', 'clicked', 'convert'];
  const foundTarget = columns.find(c => targetKeywords.some(keyword => c.toLowerCase().includes(keyword)));

  if (foundTarget) {
    suggestedTarget = foundTarget;
    const isTargetNumeric = numericColumns.includes(foundTarget);
    const uniqueTargetCount = new Set(data.map(r => r[foundTarget])).size;

    if (uniqueTargetCount <= 5) {
      problemType = 'Classification';
    } else if (isTargetNumeric) {
      problemType = 'Regression';
    } else {
      problemType = 'Classification';
    }
  } else if (hasDate && numericCount > 0) {
    problemType = 'Forecasting';
    suggestedTarget = numericColumns.find(c => c.toLowerCase().includes('sales') || c.toLowerCase().includes('revenue') || c.toLowerCase().includes('count') || c.toLowerCase().includes('spend')) || numericColumns[0];
  } else if (numericCount > 1) {
    // Look for target or default to last numeric
    problemType = 'Regression';
    suggestedTarget = numericColumns[numericColumns.length - 1];
  } else {
    problemType = 'Clustering';
  }

  return {
    name: fileName,
    rows: rowsCount,
    columns: columns.length,
    memoryKb,
    missingValues,
    duplicateRows,
    outliersCount,
    healthScore,
    correlationScore,
    columnProfiles,
    correlationMatrix,
    sampleData: data.slice(0, 100), // top 100 rows
    problemType,
    suggestedTarget
  };
}

// ----------------------------------------------------------------------
// Forecasting Math (Simple regression + seasonality wrapper)
// ----------------------------------------------------------------------
export function generateForecast(data: Record<string, any>[], dateCol: string, targetCol: string, periods = 12) {
  // Sort data by date
  const sorted = [...data].filter(r => r[dateCol] && typeof r[targetCol] === 'number').sort((a, b) => {
    return new Date(a[dateCol]).getTime() - new Date(b[dateCol]).getTime();
  });

  if (sorted.length < 3) return [];

  const xVals = sorted.map((_, i) => i);
  const yVals = sorted.map(r => r[targetCol]);

  // Linear Regression y = mx + b
  const n = xVals.length;
  let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
  for (let i = 0; i < n; i++) {
    sumX += xVals[i];
    sumY += yVals[i];
    sumXY += xVals[i] * yVals[i];
    sumXX += xVals[i] * xVals[i];
  }

  const denominator = (n * sumXX - sumX * sumX);
  const m = denominator !== 0 ? (n * sumXY - sumX * sumY) / denominator : 0;
  const b = (sumY - m * sumX) / n;

  // Historical predictions & forecast
  const historical = sorted.map((r, i) => {
    const trend = m * i + b;
    return {
      date: r[dateCol],
      actual: r[targetCol],
      predicted: Math.max(0, Math.round(trend * 100) / 100),
      isForecast: false,
      lowerBound: null,
      upperBound: null
    };
  });

  // Generate forecast
  const forecast: any[] = [];
  const lastDate = new Date(sorted[sorted.length - 1][dateCol]);
  const intervalDays = 7; // assume weekly if not daily

  for (let i = 0; i < periods; i++) {
    const forecastIndex = n + i;
    const futureDate = new Date(lastDate);
    futureDate.setDate(lastDate.getDate() + (i + 1) * intervalDays);

    const trend = m * forecastIndex + b;
    // Add artificial seasonality/fluctuation for realistic preview
    const fluctuation = Math.sin(forecastIndex) * (m ? Math.abs(m) * 2 : 10);
    const predicted = Math.max(0, Math.round((trend + fluctuation) * 100) / 100);

    const margin = Math.round((predicted * 0.15 + (i * 3)) * 100) / 100;

    forecast.push({
      date: futureDate.toISOString().split('T')[0],
      actual: null,
      predicted,
      isForecast: true,
      lowerBound: Math.max(0, Math.round((predicted - margin) * 100) / 100),
      upperBound: Math.round((predicted + margin) * 100) / 100
    });
  }

  return [...historical, ...forecast];
}
