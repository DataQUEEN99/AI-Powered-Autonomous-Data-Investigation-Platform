/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { parseCSV, generateDatasetProfile, PRELOADED_DATASETS, generateForecast } from "./server/analyzer";
import { investigateDatasetWithAI, generateAIInsights, chatWithDataset } from "./server/gemini";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Configure generous body limits for large uploaded datasets
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // ----------------------------------------------------------------------
  // Analytical and AI API Routes
  // ----------------------------------------------------------------------

  // List preloaded cases
  app.get("/api/datasets", (req, res) => {
    const list = Object.entries(PRELOADED_DATASETS).map(([id, item]) => ({
      id,
      name: item.name,
      description: item.description
    }));
    res.json(list);
  });

  // Get specific preloaded dataset parsed profile
  app.get("/api/datasets/:id", (req, res) => {
    const id = req.params.id;
    const item = PRELOADED_DATASETS[id];
    if (!item) {
      return res.status(404).json({ error: "Preloaded dataset not found" });
    }

    try {
      const parsedData = parseCSV(item.data);
      const profile = generateDatasetProfile(item.name, parsedData);
      res.json({
        profile,
        crimeContext: item.crimeContext
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to process preloaded dataset" });
    }
  });

  // Analyze raw CSV or JSON content uploaded by the user
  app.post("/api/analyze-raw", (req, res) => {
    const { fileName, fileContent } = req.body;
    if (!fileName || !fileContent) {
      return res.status(400).json({ error: "Missing fileName or fileContent parameter." });
    }

    try {
      let parsedData: any[] = [];
      if (fileName.endsWith(".json")) {
        parsedData = JSON.parse(fileContent);
        if (!Array.isArray(parsedData)) {
          // If it's a nested object, check if there's an array field or wrap it
          if (typeof parsedData === 'object' && parsedData !== null) {
            const possibleArray = Object.values(parsedData).find(val => Array.isArray(val));
            if (possibleArray) {
              parsedData = possibleArray;
            } else {
              parsedData = [parsedData];
            }
          } else {
            throw new Error("JSON file must contain an array of records.");
          }
        }
      } else {
        // Fallback to CSV parser
        parsedData = parseCSV(fileContent);
      }

      if (parsedData.length === 0) {
        throw new Error("No readable rows or records could be parsed. Check headers and formatting.");
      }

      const profile = generateDatasetProfile(fileName, parsedData);
      res.json(profile);
    } catch (err: any) {
      console.error("Analysis failed:", err);
      res.status(400).json({ error: err.message || "Invalid dataset format. Please upload a valid CSV or JSON file." });
    }
  });

  // Perform AI Detective Investigation on profile
  app.post("/api/investigate", async (req, res) => {
    const { profile, contextPrompt } = req.body;
    if (!profile) {
      return res.status(400).json({ error: "Missing dataset profile for investigation." });
    }

    try {
      const caseReport = await investigateDatasetWithAI(profile, contextPrompt);
      res.json(caseReport);
    } catch (err: any) {
      res.status(500).json({ error: err.message || "AI investigation failed" });
    }
  });

  // Generate Executive AI Insights
  app.post("/api/insights", async (req, res) => {
    const { profile } = req.body;
    if (!profile) {
      return res.status(400).json({ error: "Missing dataset profile for insights." });
    }

    try {
      const insights = await generateAIInsights(profile);
      res.json(insights);
    } catch (err: any) {
      res.status(500).json({ error: err.message || "AI insights generation failed" });
    }
  });

  // Forecast metrics
  app.post("/api/forecast", (req, res) => {
    const { data, dateCol, targetCol, periods } = req.body;
    if (!data || !dateCol || !targetCol) {
      return res.status(400).json({ error: "Missing forecasting parameters." });
    }

    try {
      const forecastData = generateForecast(data, dateCol, targetCol, periods || 12);
      res.json(forecastData);
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Forecasting calculations failed." });
    }
  });

  // Chat with dataset
  app.post("/api/chat", async (req, res) => {
    const { profile, messages } = req.body;
    if (!profile || !messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Missing profile or message history." });
    }

    try {
      const answer = await chatWithDataset(profile, messages);
      res.json({ answer });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Chat exploration failed" });
    }
  });

  // Mock server/audit logs for admin panel
  app.get("/api/logs", (req, res) => {
    const current = new Date();
    const mockLogs = [
      { timestamp: new Date(current.getTime() - 1000 * 15).toISOString(), service: "SHERLOCK_AI", level: "INFO", message: "Detective engine initialized successfully." },
      { timestamp: new Date(current.getTime() - 1000 * 180).toISOString(), service: "EDA_MATH", level: "INFO", message: "Pearson product-moment correlation matrix computed in 3ms." },
      { timestamp: new Date(current.getTime() - 1000 * 500).toISOString(), service: "FORECAST_SYS", level: "INFO", message: "Auto-regressive seasonality factors fitted to baseline target." },
      { timestamp: new Date(current.getTime() - 1000 * 900).toISOString(), service: "GEMINI_GATE", level: "SUCCESS", message: "Model gemini-3.5-flash response extracted via system schema." },
      { timestamp: new Date(current.getTime() - 1000 * 1500).toISOString(), service: "SECURITY_AUTH", level: "INFO", message: "Token claims resolved successfully. Session active." },
      { timestamp: new Date(current.getTime() - 1000 * 2500).toISOString(), service: "STORAGE_MGR", level: "INFO", message: "CSV stream cached in RAM for session isolation." }
    ];
    res.json(mockLogs);
  });

  // ----------------------------------------------------------------------
  // Vite Integration (Static Asset / Middleware Serving)
  // ----------------------------------------------------------------------
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Data Detective AI Server] Live and investigating on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Critical: Dev/Server failed to boot:", err);
});
